package pageObject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;

public class PagePrincipaleDSE{
	private WebDriver driver;

	public PagePrincipaleDSE(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

//private WebDriver driver;
@FindBy (xpath="//*[contains(text(), 'Etudiant')]") WebElement BtnEtudiant;
@FindBy (xpath="//*[contains(text(), 'Dossier')][@href]") WebElement BtnDossier;
@FindBy (xpath="//a[@href='/aglae3/dseGestion/fil?action=Ouvrir']") WebElement BtnFil;
@FindBy (xpath="//a[@href='/aglae3/dseGestion/frat?action=Ouvrir']") WebElement BtnFratrie;
@FindBy (xpath="//tr[3]/td[1]/a/img[@alt='Ajout Voeu']") WebElement BtnAjoutVoeu1;
@FindBy (xpath="//input[@value='Quitter']") WebElement BtnQuitter;
@FindBy (xpath="//input[@value='Enregistrer']") WebElement BtnEnregistrer;
@FindBy (xpath="//input[@type='checkbox'][@name='pjd']") WebElement CaseCocherPJD;
@FindBy (xpath="//input[@type='checkbox'][@name='caseG']") WebElement CaseCocherG;
@FindBy (xpath="//input[@type='checkbox'][@name='avecDse']") WebElement CaseCocherDse;
@FindBy (xpath="//input[@type='checkbox'][@name='avecNotif']") WebElement CaseCocherNU;
@FindBy (xpath="//input[@type='checkbox'][@name='nuVoeu0']") WebElement CaseCocherVoeu0;
@FindBy (xpath="//input[@type='checkbox'][@name='courriel']") WebElement CaseCocherCourriel;
@FindBy (xpath="//input[@value='Enregistrer']") WebElement BoutonEnregistrer;
@FindBy (xpath="//tbody/tr[2]/td[1]/a[text()='Historique']") WebElement BoutonCVHistorique;
@FindBy (xpath="//tr[5]/td[1]/b/a/img") WebElement BoutonCreerVoeuZero;
@FindBy (xpath="//td[4]/table/tbody/tr[1]/td[1]/a") WebElement BoutonOuvrirAidesPayees;
@FindBy (xpath="//tr[5]/td[1]/b/a") WebElement BoutonOuvrirVoeuZero;
@FindBy (xpath="/html/body/form/table[2]//td[3]/table[1]/tbody/tr[2]/td/a") WebElement BoutonLoupeTexte;

//Elements de la section "Autres"
@FindBy (xpath="//table[2]//td[1]/table[3]/tbody/tr[3]/td//tr[2]/td/a") WebElement Instructions;
@FindBy (xpath="//table[2]//td[1]/table[3]/tbody/tr[3]/td//tr[5]/td/a") WebElement Editions;
@FindBy (xpath="//table[2]//td[1]/table[3]/tbody/tr[3]/td//tr[15]/td/a") WebElement Contact;

	public void AssertAllElementsOfPagePrincipaleDSE () {
		//Vérifier la présence des tables
	    driver.findElements(By.xpath("//a[@href='/aglae3/dseGestion/etu?action=Ouvrir']"));
	    driver.findElements(By.xpath("//a[@href='/aglae3/dseGestion/dos?action=Ouvrir']"));
	    driver.findElement(By.xpath("//td[contains(text(), 'Autres')]"));
	    driver.findElements(By.xpath("//a[@href='/aglae3/dseGestion/text?action=Créer']"));
	    driver.findElement(By.xpath("//td[contains(text(), 'Paiements - Occupation')]"));
	    driver.findElement(By.xpath("//td[contains(text(), 'Curriculum Vitae')]"));
	    driver.findElement(By.xpath("//td[contains(text(), 'Voeux')]"));
	    //Boutons d'action disponibles
	    driver.findElement(By.xpath("//input[@value='Enregistrer']"));
	    driver.findElement(By.xpath("//input[@value='Diagnostic']"));
	    driver.findElement(By.xpath("//input[@value='Quitter']"));
	    //Cases à cocher
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='pjd']"));
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='caseG']"));
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='avecDse']"));
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='avecNotif']"));
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='nuVoeu0']"));
	    driver.findElement(By.xpath("//input[@type='checkbox'][@name='courriel']"));
	}
		//Récuperer l'INE du dossier
		public String INEdossier(WebDriver driver) {
			WebElement ligneINEdossier = driver.findElement(By.xpath("/html/body/form/table[1]/tbody/tr[1]/td[1]"));
			String ligneINEdossierPrimitif = ligneINEdossier.getText();
			String[] partie1INEDossier = ligneINEdossierPrimitif.split(" - ");
			String INEdossier = partie1INEDossier[0];
			return INEdossier;
		}
	
	public PageEtudiant clicketudiant() {
		BtnEtudiant.click();
		return PageFactory.initElements(driver, PageEtudiant.class);
	}
	
	public PageTexte clickLoupeTexte() {
		BoutonLoupeTexte.click();
		return PageFactory.initElements(driver, PageTexte.class);
	}
	
	public PageDossier clickdossier() {
		BtnDossier.click();
		return PageFactory.initElements(driver, PageDossier.class);
	}
	
	public PageHistorique clickHistorique() {
		BoutonCVHistorique.click();
		return PageFactory.initElements(driver, PageHistorique.class);
	}
	
	//cliquer sur le bouton Enregistrer (pour duh... Enregistrer le dossier)
	public void clickEnregistrer() {
		BoutonEnregistrer.click();
	}
	 
	//cliquer sur le bouton Quitter et quitter le DSE actuel
  	public PageDossiersGestion QuitterDossierValide() throws Exception {
		 BtnQuitter.click();
		 driver.switchTo().alert().accept();
		return PageFactory.initElements(driver, PageDossiersGestion.class);
	}
 
/*
 * PAIEMENTS - OCCUPATION
 * OPERATIONS SUR LES VOEUX 0
 */
 
  	//Ajouter un voeu0 dans "paiements - occupation"
  	public PageVoeu0 AjouterVoeu0() {
  		BoutonCreerVoeuZero.click();
  		return PageFactory.initElements(driver, PageVoeu0.class);
  	}
  	
  	//Ouvrir le voeu0 dans "paiements - occupation"
  	public PageVoeu0 OuvrirVoeu0() {
  		BoutonOuvrirVoeuZero.click();
  		return PageFactory.initElements(driver, PageVoeu0.class);
  	}
  	
  	//Cliquer sur bouton "10" de Paiement/Aide
  	
	public PagePaiementVoeu0 OuvrirAidePaiement(int ordreAide0) {
		WebElement AideVoeu0 = driver.findElement(By.xpath("//td[4]/table/tbody/tr["+ordreAide0+"]/td[1]/a"));
		AideVoeu0.click();
		return PageFactory.initElements(driver, PagePaiementVoeu0.class);
	}



/*
 * en lien avec l'element commenté 
 *    Guillaume GARDERE	
	public void clickfeurouge() {
		BtnFeurouge.click();
	}
*/
	/**
	 * Cette methode permet de recuperer les valeurs contenu dans le tableau de diagnostic suite a un remplissage d'une des partie de l'écran, Etudiant, dossiers..;
	 * En l'occurence le but est de verifier la présence d'éléments dans "diagnostic" a partir du moment ou on renseigne une zone.
	 * 
	 * La méthode renvoie une map<String,String>
	 * 
	 */
  	//Méthode pour vérifier la liste de messages d'erreur affichés par rapport à une liste attendue
	public Map<String, String> recupMapDiagnostic(WebDriver driver) {
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}
	
	//Méthode pour vérifier la liste des messages de confirmation affichés par rapport à une liste attendue
	public Map<String, String> recupMapPositif(WebDriver driver) {
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='info']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='info']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}
	
	public PageFil clickfil() {
		BtnFil.click();
		return PageFactory.initElements(driver, PageFil.class);
	}
	
	public PageFratrie clickfratrie() {
		BtnFratrie.click();
		return PageFactory.initElements(driver, PageFratrie.class);
	}
	
	
	//Méthodes pour la section "Autres"
	public PageInstructions clickInstructions() {
		Instructions.click();
		return PageFactory.initElements(driver, PageInstructions.class);
	}
	
	public PageEditions clickEditions() {
		Editions.click();
		return PageFactory.initElements(driver, PageEditions.class);
	}
	
	public PageContact clickContact() {
		Contact.click();
		return PageFactory.initElements(driver, PageContact.class);
	}
	
	
	
	//Méthodes pour les voeux
	
		//Ajouter un voeu (le plus sur lequel on clique est déterminé par la valeur de l'integer, 1 pour ligne1, 2 pour ligne 2 etc...)	
		public PageVoeux clickVoeuxPlus(int ligneAjoutVoeu) {
			int NbLigneVoeuAjout = (ligneAjoutVoeu*2)+1;
			WebElement PlusVoeu = driver.findElement(By.xpath("//tr["+NbLigneVoeuAjout+"]/td[1]/a/img[@alt='Ajout Voeu']"));
			PlusVoeu.click();
			return PageFactory.initElements(driver, PageVoeux.class);
		}
		
		//Editer un voeu (le voeu sur lequel on clique est déterminé par la valeur de l'integer, 1 pour ligne1, 2 pour ligne 2 etc...)	
		public PageVoeux clickVoeuxEditer(int ligneEditVoeu) {
			WebElement NbLigneVoeuEdit = driver.findElement(By.xpath("//a[@accesskey='"+ligneEditVoeu+"']"));
			NbLigneVoeuEdit.click();
			return PageFactory.initElements(driver, PageVoeux.class);
		}
		
		//Methode pour mettre en logement un voeu	
		public void clickMiseLogement(int ligneMiseLogement) {
			int NbLigneVoeu = (ligneMiseLogement*2)+2;
			WebElement miseEnLogementSpecifique = driver.findElement(By.xpath("//tr["+ NbLigneVoeu +"]/td[7]//tr[2]/td[2]/a/img"));
			miseEnLogementSpecifique.click();
			driver.switchTo().alert().accept();
		}
		
		//Methode pour mettre en paiement un voeu	
		public void clickMisePaiement(int ligneMisePaiement) {
			int NbLigneVoeu = (ligneMisePaiement*2)+2;
			WebElement miseEnPaiementSpecifique = driver.findElement(By.xpath("//tr["+ NbLigneVoeu +"]/td[7]//tr[2]/td[1]/a/img"));
			miseEnPaiementSpecifique.click();
			driver.switchTo().alert().accept();
		}
		
		//Verifier qu'après affectation, les autres voeux sont passés en statut F
		public void verifStatutFsurLigneVoeuChoisie(int ligneMisePaiement) {
			int NbLigneVoeu = (ligneMisePaiement*2)+2;
			driver.findElement(By.xpath("//tr["+NbLigneVoeu+"]/td[3]/table/tbody/tr[2]/td[contains(text(), 'F - ')]"));

		}
		
		//Clic sur les flèches de changement d'ordre du voeu
			//Cliquer sur les flèches de changement d'ordre du voeu (vers le haut)
			public void deplacerVoeuHaut(int ligneABouger) {
				int NbLigneVoeu = (ligneABouger*2)+2;
				WebElement flecheHaut = driver.findElement(By.xpath("//tr["+NbLigneVoeu+"]/td[7]/table/tbody/tr[1]/td/a/img"));
				flecheHaut.click();
			}
			
			//Cliquer sur les flèches de changement d'ordre du voeu (vers le bas)
			public void deplacerVoeuBas(int ligneABouger) {
				int NbLigneVoeu = (ligneABouger*2)+2;
				WebElement flecheBas = driver.findElement(By.xpath("//tr["+NbLigneVoeu+"]/td[7]/table/tbody/tr[3]/td/a/img"));
				flecheBas.click();
			}
			
		
	//Cocher cases du dessus
	public void CaseCocherPJD() {
		CaseCocherPJD.click();
	}
	
	public void CaseCocherG() {
		CaseCocherG.click();
	}

	public void CaseCocherDse() {
		CaseCocherDse.click();
	}
	
	public void CaseCocherNU() {
		CaseCocherNU.click();
	}
	
	public void CaseCocherVoeu0() {
		CaseCocherVoeu0.click();
	}
	
	public void CaseCocherCourriel() {
		CaseCocherCourriel.click();
	}
	//Fin des des cases du dessus
	
	//Verifier les masques de paiement
	public void verifElementsPaiements (int ligneMasquePaiement) {
		//Récupérer le masque de paiement
		WebElement ligneAideMasque = driver.findElement(By.xpath("//tr[5]/td[4]//tr["+ligneMasquePaiement+"]/td[3]"));
		String resultMasquePaiement = ligneAideMasque.getText();
		
		//Récupérer le mois de la mise en paiement
		WebElement ligneMisePaiement = driver.findElement(By.xpath("//tr[5]/td[4]//tr["+ligneMasquePaiement+"]/td[4]"));
		String resultMisePaiement = ligneMisePaiement.getText();
		String mois = resultMisePaiement.split("/")[1];
		System.out.println("Mois = " + mois);
		
		//Récupérer la valeur la bourse en fonction du code de l'aide complémentaire (ou principale)
		String bourse = null;
		String ligneAidePayee = driver.findElement(By.xpath("//tr[5]/td[4]//tr["+ligneMasquePaiement+"]/td[1]")).getText();
		switch (ligneAidePayee) {
		case "10":
			bourse = "10";
			break;
		case "CA":
			bourse = driver.findElement(By.xpath("//tr[5]/td[4]//tr[1]/td[1]")).getText();
			break;
		case "DM":
			bourse = "45";
			break;
		}
		System.out.println("codeAide = " + ligneAidePayee);
		System.out.println("Bourse = " + bourse);
		
		//valeur de l'aide principale (utile pour certaines aides complémentaires)
		String codeAidePrincipale = driver.findElement(By.xpath("//tr[5]/td[4]//tr[1]/td[1]")).getText();
		String bourseValeur = driver.findElement(By.xpath("//tr[5]/td[4]//tr["+ligneMasquePaiement+"]/td[2]")).getText();
		String valeurDeLaBourse = bourseValeur.replaceAll("[^0-9.]", "");
		System.out.println("Dec. = " + valeurDeLaBourse);
		
		//code final d'assertion du masque de paiement rapport à l'attendu
		if (ligneAidePayee.equals("CA")) {
				assertEquals("BBBBBBBBBBBBBBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse, resultMasquePaiement);
		} else {
			switch (mois) {
			case "01":
				assertEquals("BBBBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "02":
				assertEquals("BBBBBBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "03":
				assertEquals("BBBBBBBBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "04":
				assertEquals("BBBBBBBBBBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "05":
				assertEquals("BBBBBBBBBBBBBBBBBB" + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "06":
				assertEquals("BBBBBBBBBBBBBBBBBBBBBBBB", resultMasquePaiement);
				break;
			case "07":
				assertEquals(valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "08":
				assertEquals(valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "09":
				assertEquals("BB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "10":
				assertEquals("BBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "11":
				assertEquals("BBBBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			case "12":
				assertEquals("BBBBBBBB" + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + valeurDeLaBourse + "BBBB", resultMasquePaiement);
				break;
			}
		}	
	}
	
	
	
	
	/********** DEBUT : METHODE DE VERIFICATION DES VOEUX  **********/
	
	/***
	 * Méthode pour vérifier la colonne des aides attendues pour les voeux /!\NE MARCHE PAS POUR VOEU 0/!\
	 * @param rangvoeu (Recupérer le rang du voeu (voeu n°1, ou 2 etc... l'int correspond au rang du voeu qu'on veut récupérer)
	 * @param colonneVoeu (Récupérer la colonne du voeu : Rien à faire à part renseigner l'int colonneVoeu /!\Les colonnes vides doivent être comptées : 2 Pour Etude, 3 Pour Logement, 5 Pour Aide(s), 7 pour Actions)
	 * @param ligneVoeu (Récupérer la ligne du voeu (ex, pour étude, c'est 1 pour académie, 2 pour cursus et 3 pour l'établissement) : Rien à faire à part renseigner l'int ligneVoeu)
	 * @return
	 */
	
		//Méthode pour sauvegarder dans une string le code de décision de l'aide du voeu 0 (pour comparaison dans l'historique, code type CE, CA, 10 etc...)
		public String sauvegardeCodeVoeu0 (int ligneCodeVoeu0) {
			WebElement ligneCode = driver.findElement(By.xpath("//tr[3]//tr[5]/td[4]/table/tbody/tr["+ ligneCodeVoeu0 +"]/td[1]"));
			String ligneCodeHist = ligneCode.getText();
			return ligneCodeHist;
		}
	
		//Méthode pour sauvegarder dans une string la valeur de la bourse d'aide du voeu 0 (pour comparaison dans l'historique, bourse type 10,20, 30, 45 etc...)
		public String sauvegardeBourseVoeu0 (int ligneBourseVoeu0) {
			WebElement ligneAide = driver.findElement(By.xpath("//tr[3]//tr[5]/td[4]/table/tbody/tr["+ ligneBourseVoeu0 +"]/td[2]"));
			String ligneAideHist = ligneAide.getText();
			return ligneAideHist;
		}
		
		//Méthode pour sauvegarder le nom de la résidence qui va passer en voeu 0
		public String sauvegardeLogementVoeu0 () {
			WebElement lignelog = driver.findElement(By.xpath("//td[3]/table[2]//td[3]/table/tbody/tr[3]/td"));
			String lignelogStr = lignelog.getText();
			String[] resultlogStr = lignelogStr.split(" - ");
			String nomLogement = resultlogStr[1];
			return nomLogement;
		}
	
	
	public String recupVoeu (int rangvoeu, int colonneVoeu, int ligneVoeu) {
		int rangVoeuFinal = (rangvoeu*2)+2;
		WebElement TPC = driver.findElement(By.xpath("//table[4]//tr["+rangVoeuFinal+"]/td["+colonneVoeu+"]/table/tbody/tr["+ligneVoeu+"]/td"));
		String result1 = TPC.getText();
		return result1;
	}
	
	//Récupérer le contenu d'une case du tableau voeu0 (les 3 premières cases uniquement)
	public String recupVoeu0premier (int colonneVoeu, int ligneVoeu) {
		WebElement TPC = driver.findElement(By.xpath("//td[3]/table[2]/tbody/tr[3]//tr[5]/td["+colonneVoeu+"]//tr["+ligneVoeu+"]"));
		String result0 = TPC.getText();
		return result0;
	}
	
	//Récupérer le contenu d'une case du tableau voeu0 (les 5 dernières cases uniquement)
	public String recupVoeu0dernier (int colonneVoeu, int ligneVoeu) {
		int colonneVoeu0Final = (colonneVoeu)-3;
		WebElement TPC = driver.findElement(By.xpath("//tr[3]//tr[5]/td[4]/table/tbody/tr["+ligneVoeu+"]/td["+colonneVoeu0Final+"]"));
		String result0 = TPC.getText();
		return result0;
	}
	
	public String recupVoeu0MotUnique (int colonneVoeu, int ligneVoeu, int quelSplit) {
		WebElement TPC = driver.findElement(By.xpath("//tr[3]//tr[5]/td["+ colonneVoeu +"]//tr["+ ligneVoeu +"]/td"));
		String result0 = TPC.getText();
		String resultPhrase = result0.split(" ")[+ quelSplit];
		System.out.println("statut logement = " + resultPhrase);
		return resultPhrase;
	}
	
		public String recupContenuTextuelEtude (int rangvoeu) {
			String ligne1Colonne2 = recupVoeu(rangvoeu, 2, 1);
			String ligne2Colonne2 = recupVoeu(rangvoeu, 2, 2);
			String ligne3Colonne2 = recupVoeu(rangvoeu, 2, 3);
			String CaseEtude = ligne1Colonne2 + ligne2Colonne2 + ligne3Colonne2;
			return CaseEtude;
		}
	
	/* //Méthode pour vérifier la liste des messages de confirmation affichés par rapport à une liste attendue
	public Map<String, String> recupMapPositif(WebDriver driver, int int1, int LigneDeLaCellule) {
		int LigneDuTableauVoeu = (int1*2)+2;
		
		List<WebElement> EtudeLigne1 = driver.findElements(By.xpath("//tr["+LigneDuTableauVoeu+"]/td[2]/table/tbody/tr["+LigneDeLaCellule+"]/td"));
		List<WebElement> EtudeLigne2 = driver.findElements(By.xpath("//tr["+LigneDuTableauVoeu+"]/td[3]/table/tbody/tr["+LigneDeLaCellule+"]/td"));
		List<WebElement> EtudeLigne3 = driver.findElements(By.xpath("//tr["+LigneDuTableauVoeu+"]/td[5]/table/tbody/tr["+LigneDeLaCellule+"]/td"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}*/
	
	
	
	/********** FIN : METHODE DE VERIFICATION DES VOEUX **********/
	
	
	
	
	
}

