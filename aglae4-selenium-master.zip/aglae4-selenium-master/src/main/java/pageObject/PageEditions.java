package pageObject;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageEditions extends SqueletteEtudiantDossier{
	
	public PageEditions(WebDriver driver) {
		
		super(driver);
		}
@FindBy (xpath="//tr[4]/td/table/tbody/tr[2]/td[1]/input") WebElement btnFermer;
	

	//Méthode pour les boutons en bas de la page
	public PagePrincipaleDSE clickFermer (WebDriver driver) {
		btnFermer.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//Méthode d'assert du bon nombre de NU
	public String recupNbNU (WebDriver driver) {
		WebElement nombreNU = driver.findElement(By.xpath("//tr[3]//tr[4]/td[1]"));
		String nbNU = nombreNU.getText();
		return nbNU;
	}
}