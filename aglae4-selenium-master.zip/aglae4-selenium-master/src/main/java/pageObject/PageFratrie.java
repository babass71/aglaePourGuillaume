package pageObject;

public class PageFratrie {

}
