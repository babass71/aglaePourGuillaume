package pageObject;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PagePaiementVoeu0 {
	private WebDriver driver;

	public PagePaiementVoeu0(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	@FindBy (xpath="//tr[7]/td/table/tbody/tr[2]/td[6]") WebElement DateEffet;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[1]") WebElement Masque1;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[2]") WebElement Masque2;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[3]") WebElement Masque3;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[4]") WebElement Masque4;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[5]") WebElement Masque5;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[6]") WebElement Masque6;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[7]") WebElement Masque7;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[8]") WebElement Masque8;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[9]") WebElement Masque9;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[10]") WebElement Masque10;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[11]") WebElement Masque11;
	@FindBy (xpath="//tr[3]//tr[2]/td[2]/input[12]") WebElement Masque12;
	@FindBy (xpath="//table[3]//tr[5]/td[2]") WebElement Decision;
	@FindBy (xpath="//tr[7]//tr[2]/td[1]") WebElement Arrete;
	@FindBy (xpath="//tr[2]/td[1]/input[1]") WebElement BtnModifier;
	@FindBy (xpath="//table[2]/tbody/tr[1]/td/table/tbody/tr/td[1]") WebElement LigneDuHaut;
	
	
	public void verifElementsPaiements () {
		//Recup�rer la date d'effet de la bourse
		String dateEffet = DateEffet.getText();
		String mois = dateEffet.split("/")[1];
		System.out.println("Mois = " + mois);
		//Recuperer la valeur de la bourse
		String decision = Decision.getText();
		String bourse = decision.split(" ")[0];
		System.out.println("Aide = " + bourse);
		//Recuperer le code de la bourse
		String bourseDecision = LigneDuHaut.getText();
		String code = bourseDecision.split(" - ")[3];
		System.out.println("Code = " + code);
		
	 
		String masque = Masque1.getAttribute("value") + Masque2.getAttribute("value") + Masque3.getAttribute("value") + Masque4.getAttribute("value") + Masque5.getAttribute("value") + Masque6.getAttribute("value") + Masque7.getAttribute("value") + Masque8.getAttribute("value") + Masque9.getAttribute("value") + Masque10.getAttribute("value") + Masque11.getAttribute("value") + Masque12.getAttribute("value");
		System.out.println("Masque = " + masque);
		
		if (code.equals("CE")) {
			assertEquals("BBBBBBBBBBBBBBBBBBBB" + bourse + bourse, masque);
		} else if (code.equals("DM")) {
			switch (mois) {
			case "01":
				assertEquals("BBBBBBBB454545454545BBBB", masque);
				break;
			case "02":
				assertEquals("BBBBBBBBBB4545454545BBBB", masque);
				break;
			case "03":
				assertEquals("BBBBBBBBBBBB45454545BBBB", masque);
				break;
			case "04":
				assertEquals("BBBBBBBBBBBBBB454545BBBB", masque);
				break;
			case "05":
				assertEquals("BBBBBBBBBBBBBBBB4545BBBB", masque);
				break;
			case "06":
				assertEquals("BBBBBBBBBBBBBBBBBB45BBBB", masque);
				break;
			case "07":
				assertEquals("45454545454545454545BBBB", masque);
				break;
			case "08":
				assertEquals("45454545454545454545BBBB", masque);
				break;
			case "09":
				assertEquals("45454545454545454545BBBB", masque);
				break;
			case "10":
				assertEquals("BB454545454545454545BBBB", masque);
				break;
			case "11":
				assertEquals("BBBB4545454545454545BBBB", masque);
				break;
			case "12":
				assertEquals("BBBBBB45454545454545BBBB", masque);
				break;
			}
		} else {
			switch (mois) {
			case "01":
				assertEquals("BBBBBBBB" + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "02":
				assertEquals("BBBBBBBBBB" + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "03":
				assertEquals("BBBBBBBBBBBB" + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "04":
				assertEquals("BBBBBBBBBBBBBB" + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "05":
				assertEquals("BBBBBBBBBBBBBBBB" + bourse + bourse + "BBBB", masque);
				break;
			case "06":
				assertEquals("BBBBBBBBBBBBBBBBBB" + bourse + "BBBB", masque);
				break;
			case "07":
				assertEquals(bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "08":
				assertEquals(bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "09":
				assertEquals(bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "10":
				assertEquals("BB" + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "11":
				assertEquals("BBBB" + bourse + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			case "12":
				assertEquals("BBBBBB" + bourse + bourse + bourse + bourse + bourse + bourse + bourse + "BBBB", masque);
				break;
			}
		}
	}
	
	public void assertArrete () {
		String ArreteStr = Arrete.getText();
		assertEquals(ArreteStr, "Pr�visionnel");
	}
	
	public PagePrincipaleDSE cliquerModifier () {
		BtnModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public void modifMasquePaiement (int nbMasqueAModifier, String nouvelleValeurMasque) {
		WebElement MasqueFinal = driver.findElement(By.xpath("//tr[3]//tr[2]/td[2]/input["+nbMasqueAModifier+"]"));
		MasqueFinal.clear();
		MasqueFinal.sendKeys(nouvelleValeurMasque);
	}
}
