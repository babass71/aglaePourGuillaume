package pageObject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;

public class PageHistorique {
	private WebDriver driver;

	public PageHistorique(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	//private WebDriver driver;
	@FindBy (xpath="//tr[2]/td[1]/input") WebElement BtnFermer;
	@FindBy (xpath="//tr[2]/td/a/img[@alt='Ajout CV']") WebElement BtnPlusCV;
	
	public CreerPageHistorique clickPlusHistorique() {
		BtnPlusCV.click();
		return PageFactory.initElements(driver, CreerPageHistorique.class);
	}
	
	public PagePrincipaleDSE clickFermerHistorique() {
		BtnFermer.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public Map<String, String> recupMapDiagnostic(WebDriver driver) {
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}
	
	public PageVoeuHistorique OuvrirVoeuDansHistorique (int ligneHisto) {
		//Vérifier la présence de la ligne
	    WebElement btnAideHisto = driver.findElement(By.xpath("//tr[3]//tr[4]/td[1]/table/tbody/tr["+ligneHisto+"]/td/a"));
	    btnAideHisto.click();
	    return PageFactory.initElements(driver, PageVoeuHistorique.class);
	}
	
	public void AssertPresenceUneLigne () {
		//Vérifier la présence de la ligne
	    driver.findElements(By.xpath("//tr[3]/td/table/tbody/tr[4]"));
	}
	
	public String recupUniversiteVoeu (int ligneVoeu) {
		int rangVoeuFinal = (ligneVoeu*2)+2;
		WebElement TPC = driver.findElement(By.xpath("//tr["+rangVoeuFinal+"]/td[2]/table/tbody/tr/td"));
		String result0 = TPC.getText();
		return result0;
	}
	
		//Récupérer le code l'aide dans l'historique
		public String VerifierCodeAideHistorique (int ligne) {
			int lignefinale = (ligne*2)+2;
		    WebElement aideHistorique = driver.findElement(By.xpath("//tr[3]//tr["+lignefinale+"]/td[4]/table/tbody/tr/td"));
		    String aideHisto = aideHistorique.getText();
		    String aideCode1 = aideHisto.split(" ")[0];
		    return aideCode1;
		}
		
		//Récupérer la valeur de l'aide dans l'historique
		public String VerifierBourseAideHistorique (int ligne) {
			int lignefinale = (ligne*2)+2;
		    WebElement aideHistorique = driver.findElement(By.xpath("//tr[3]//tr["+lignefinale+"]/td[4]/table/tbody/tr/td"));
		    String aideHisto = aideHistorique.getText();
		    String aideCode2 = aideHisto.split(" ")[1];
		    return aideCode2;
		}
	
}
