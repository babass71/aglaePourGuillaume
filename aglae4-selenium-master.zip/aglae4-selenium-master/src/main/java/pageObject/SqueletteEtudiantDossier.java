package pageObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.OutilsProjet;

public abstract class SqueletteEtudiantDossier {

	// public WebDriver driver;

	public SqueletteEtudiantDossier(WebDriver driver) {
		
		super();
		// this.driver = driver;
		
		}
	@FindBy (xpath="//td[.='Création']/following-sibling::td[1]") WebElement dateCreation;
	@FindBy (xpath="//td[.='Modification']/following-sibling::td[1]") WebElement dateModification;
	
	@FindBy (xpath="//input[@value='Modifier'][@type='submit']") WebElement boutonmModifier;
	@FindBy (xpath="//input[@value='Annuler'][@type='submit']") WebElement boutonmAnnuler;
	
	
	public String recupNombreBloc(WebDriver driver) {
		List<WebElement> listeWebElementBloc =driver.findElements(By.xpath("//td[@class='titrebloc']"));
		int nombre = listeWebElementBloc.size();
		String nombreString = String.valueOf(nombre);
		return nombreString;
	}

	public String recupDateCreation () {
		String date = dateCreation.getText();
		return date ;
		
	}
	
	public String recupDateModification () {
		String date = dateModification.getText();
		return date ;
	}
	
	public Map<String,String> recupDignostic(WebDriver driver){
		
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
		
	}
}
