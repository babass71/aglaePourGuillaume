package pageObject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;

public class PageVoeuHistorique {
	private WebDriver driver;

	public PageVoeuHistorique(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	//private WebDriver driver;
	@FindBy (xpath="//tr[6]//tr[2]/td[1]/input[1]") WebElement BtnModifier;
	@FindBy (xpath="//tr[6]//tr[2]/td[1]/input[2]") WebElement BtnAnnuler;
	
	public PageHistorique clickModifierVoeuHistorique() {
		BtnModifier.click();
		return PageFactory.initElements(driver, PageHistorique.class);
	}
	
	public PageHistorique clickAnnulerVoeuHistorique() {
		BtnAnnuler.click();
		return PageFactory.initElements(driver, PageHistorique.class);
	}
}
