package utils;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class MapFilter<K,V> {

    private final Map<K,V> mapToFilter;

    public MapFilter(Map<K, V> mapToFilter) {
        this.mapToFilter = Collections.unmodifiableMap(mapToFilter);
    }

    /**
     *  Return an ensemble of keys whose associated values in the
     *  map are equals to the param Value.
     *
     * @param value The filter value
     *
     * @return an unmodifiable collection of keys whose associated values in the
     * map are equals to the param Value.
     */
    public Set<K> filter(V value) {

        final Set<K> initialKeys = mapToFilter.keySet();
        final Set<K> filteredKeys = new HashSet<>();

        for (K currentKey : initialKeys ) {
            final V keyValue = mapToFilter.get(currentKey);
            if (value.equals(keyValue)) {
                filteredKeys.add(currentKey);
            }
        }

        return Collections.unmodifiableSet(filteredKeys);
    }
}
