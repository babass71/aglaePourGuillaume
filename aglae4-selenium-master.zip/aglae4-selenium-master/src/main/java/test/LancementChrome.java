package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;
import pageObject.PageDossier;
import pageObject.PageDossiersGestion;
import pageObject.PageEditions;
import pageObject.PageEtudiant;
import pageObject.PageHistorique;
import pageObject.PageInstructions;
import pageObject.PageLogin;
import pageObject.PagePaiementVoeu0;
import pageObject.PagePrincipaleDSE;
import pageObject.PageTexte;
import pageObject.PageVoeu0;
import pageObject.PageVoeuHistorique;
import pageObject.PageVoeux;
import pageObject.PageHistorique;
import pageObject.CreerPageHistorique;
import pageObject.PageContact;
import utils.OutilsProjet;

public class LancementChrome extends ChromeDriverSetup{
	
	@SuppressWarnings("deprecation")
	@Test
	public void run() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		PageLogin pageLogin = PageFactory.initElements(driver, PageLogin.class);
		Properties properties = new Properties();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream("fileCasNomial.properties");
	}
}