package test;


import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import utils.OutilsProjet;

public class FirefoxDriverSetup {

	protected static WebDriver driver;
	
	protected static final Logger LOGGER = LoggerFactory.getLogger("LoggerTest");
	public FirefoxDriverSetup() {
		LOGGER.info("Debut du test");
		String urlFirefoxdriver = OutilsProjet.class.getClassLoader().getResource("drivers/geckodriver.exe").getPath();
			LOGGER.info("le getPath est OK"+ urlFirefoxdriver);
			System.out.println("URL FD : " + urlFirefoxdriver);
		System.setProperty("webdriver.gecko.driver", urlFirefoxdriver);
			LOGGER.info("le setProperty est OK");
		driver = new FirefoxDriver();
			LOGGER.info("le new webdriver a été lancé");
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		LOGGER.info("Webdriver lancé");
		driver.get("https://aglaestage.ac-paris.fr/aglae3/");	
		
		
		
	}
	@After
	public void close() {
		driver.close();
	}
	
}