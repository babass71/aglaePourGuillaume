package test;


import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import utils.OutilsProjet;

public class ChromeDriverSetup {

	protected static WebDriver driver;

	protected static final Logger LOGGER = LoggerFactory.getLogger("LoggerTest");
	public ChromeDriverSetup() {
		LOGGER.info("Debut du test");
		String urlChromdriver = OutilsProjet.class.getClassLoader().getResource("drivers/chromedriver.exe").getPath();
		LOGGER.info("le getPath est OK"+ urlChromdriver);
		System.out.println("URL FD : " + urlChromdriver);
		System.setProperty("webdriver.chrome.driver", urlChromdriver);
		driver = new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		LOGGER.info("Webdriver lancé");
		driver.get("https://aglaestage.ac-paris.fr/aglae3/");	
		
		
		
	}
	@After
	public void close() {
		driver.close();
	}
	
}