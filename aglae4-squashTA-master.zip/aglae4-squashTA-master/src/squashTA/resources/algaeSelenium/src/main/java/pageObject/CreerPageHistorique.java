package pageObject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class CreerPageHistorique {
	private WebDriver driver;

	public CreerPageHistorique(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	//LISTE METHODES DES BOUTONS ACTION
		//Partie Boutons d'actions "ajouter - annuler - editer"
		@FindBy (xpath="//tr[2]/td[1]/input[1]") WebElement BtnAjouter;
		@FindBy (xpath="//tr[2]/td[1]/input[2]") WebElement BtnAnnuler;
		
		//Méthode validation d'un voeu
		public PageHistorique clickAjouter(WebDriver driver) {
			BtnAjouter.click();
			return PageFactory.initElements(driver, PageHistorique.class);
		}
		
		//Méthode annulation d'un voeu
		public PageHistorique clickAnnuler(WebDriver driver) {
			BtnAnnuler.click();
			return PageFactory.initElements(driver, PageHistorique.class);
		}
	
	
	
	
	//LISTE METHODES DE LA SECTION "CURRICULUM VITAE"
		//Partie Curriculum Vitae
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[2]/td[2]/input") WebElement AnneeHisto;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[3]/td[2]/input") WebElement NumOrdre;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[4]/td[2]/input") WebElement RangVoeu;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[5]/td[2]/input") WebElement NumChrono;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[6]/td[2]/select") WebElement CROUSGestion;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[7]/td[2]/input") WebElement Diplome;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[8]/td[2]/input") WebElement Mention;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[9]/td[2]/input") WebElement NbCredValides;
		@FindBy (xpath="//td[1]/table/tbody/tr[3]//tr[10]/td[2]/input") WebElement NbDroitsCons;

		//méthode entrée Année histo
		public void selectAnneeHisto (String annee) {
			AnneeHisto.sendKeys(Keys.CONTROL, "a");
			AnneeHisto.sendKeys(annee);
		}
		
		//méthode entrée numéro d'ordre
		public void selectNumOrdre (String numero) {
			NumOrdre.sendKeys(Keys.CONTROL, "a");
			NumOrdre.sendKeys(numero);
		}
		
		//méthode entrée rang voeu
		public void selectRangVoeu (String rgVoeu) {
			RangVoeu.sendKeys(Keys.CONTROL, "a");
			RangVoeu.sendKeys(rgVoeu);
		}
		
		//méthode entrée num Chrono
		public void selectNumVoeu (String numChr) {
			NumChrono.sendKeys(numChr);
		}
		
		//méthode sélection Crous Gestion
		public void selectCrousGestion (String crous) {
			Select dropdown = new Select(CROUSGestion);
			dropdown.selectByValue(crous);
		}
		
		//méthode entrée Diplome
		public void selectDiplome (String diplome) {
			Diplome.sendKeys(diplome);
		}
		
		//méthode entrée Mention
		public void selectMention (String mention) {
			Mention.sendKeys(mention);
		}
		
		//méthode entrée Nb crédits validés
		public void selectCredValides (String credits) {
			NbCredValides.sendKeys(credits);
		}
		
		//méthode entrée Nb droits conssommés
		public void selectDroitsConsn (String droits) {
			NbCredValides.sendKeys(droits);
		}
		
		
		public void remplissageCurriculumVitae(String annee, String numero, String rgVoeu, String numChr, String crous, String diplome, String mention, String credits, String droits) {
			//remplir la partie "Aides"
			selectAnneeHisto(annee);
			selectNumOrdre(numero);
			selectRangVoeu(rgVoeu);
			selectNumVoeu(numChr);
			selectCrousGestion(crous);
			selectDiplome(diplome);
			selectMention(mention);
			selectCredValides(credits);
			selectDroitsConsn(droits);
		}
		
		
		
	//LISTE METHODES DE LA SECTION "..."
		//Partie "..."
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[2]/td[2]/select") WebElement Pays;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[3]/td[2]/select") WebElement Academie;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[4]/td[2]/select") WebElement Secteur;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[5]/td[2]/input") WebElement Etablissement;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[8]/td[2]/select") WebElement TypCursus;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[9]/td[2]/select") WebElement Formation;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[10]/td[2]/select") WebElement ProgLMD;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[11]/td[2]/select") WebElement BrancheLMD;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[12]/td[2]/input") WebElement Niveau;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[13]/td[2]/select") WebElement Cesure;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[14]/td[2]/select") WebElement SemestreLMD;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[16]/td[2]/select") WebElement TypLogement;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[17]/td[2]/select") WebElement AcLogement;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[18]/td[2]/select") WebElement ScLogement;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[19]/td[2]/input") WebElement ResLogement;
		@FindBy (xpath="//td[3]/table/tbody/tr[3]//tr[20]/td[2]/select") WebElement CodDecLogement;
		
		//Remplissage de la totalité de la section "..."
		public void remplissageTroisPoints(String pays, String academie, String secteur, String etablissement, String typcursus, String formation, String progLMD, String brancheLMD, String niveau, String cesure, String semestreLMD, String typlogement, String aclogement, String sclogement, String residence, String coddeclogement) {
			//remplir la partie "Aides"
			selectPays(pays);
			selectAcademie(academie);
			selectSecteur(secteur);
			remplirEtablissement(etablissement);
			selectTypCursus(typcursus);
			selectFormation(formation);
			selectProgLMD(progLMD);
			selectBrancheLMD(brancheLMD);
			selectNiveau(niveau);
			selectCesure(cesure);
			selectSemestreLMD(semestreLMD);
			selectTypLogement(typlogement);
			selectAcLogement(aclogement);
			selectScLogement(sclogement);
			remplirResidence(residence);
			selectCodDecLogement(coddeclogement);
		}
		
		//méthode sélection Pays
		public void selectPays (String pays) {
			Select dropdown = new Select(Pays);
			dropdown.selectByValue(pays);
		}
		
		//méthode sélection Academie
		public void selectAcademie (String academie) {
			Select dropdown = new Select(Academie);
			dropdown.selectByValue(academie);
		}
		
		//méthode sélection secteur
		public void selectSecteur (String secteur) {
			Select dropdown = new Select(Secteur);
			dropdown.selectByValue(secteur);
		}
		
		//méthode remplissage champ cp
		public void remplirEtablissement(String etablissement) {
			Etablissement.sendKeys(etablissement);
		}
		
		//méthode sélection Type cursus
		public void selectTypCursus (String typcursus) {
			Select dropdown = new Select(TypCursus);
			dropdown.selectByValue(typcursus);
		}
		
		//méthode sélection Type formation
		public void selectFormation (String formation) {
			Select dropdown = new Select(Formation);
			dropdown.selectByValue(formation);
		}
		
		//méthode sélection Type cursus
		public void selectProgLMD (String progLMD) {
			Select dropdown = new Select(ProgLMD);
			dropdown.selectByValue(progLMD);
		}
		
		//méthode sélection Branche LMD
		public void selectBrancheLMD (String brancheLMD) {
			Select dropdown = new Select(BrancheLMD);
			dropdown.selectByValue(brancheLMD);
		}
		
		//méthode sélection Type Niveau
		public void selectNiveau (String niveau) {
			Niveau.sendKeys(niveau);
		}
	
		//méthode sélection Type Cesure
		public void selectCesure (String cesure) {
			Select dropdown = new Select(Cesure);
			dropdown.selectByValue(cesure);
		}
		
		//méthode sélection Type Semestre LMD
		public void selectSemestreLMD (String semestreLMD) {
			Select dropdown = new Select(SemestreLMD);
			dropdown.selectByValue(semestreLMD);
		}
		
		//méthode sélection Type Type de logement
		public void selectTypLogement (String typlogement) {
			Select dropdown = new Select(TypLogement);
			dropdown.selectByValue(typlogement);
		}
		
		//méthode sélection Académie du logement
		public void selectAcLogement (String aclogement) {
			Select dropdown = new Select(AcLogement);
			dropdown.selectByValue(aclogement);
		}
		
		//méthode sélection secteur logement
		public void selectScLogement (String sclogement) {
			Select dropdown = new Select(ScLogement);
			dropdown.selectByValue(sclogement);
		}
		
		//méthode remplissage Résidence
		public void remplirResidence(String residence) {
			ResLogement.sendKeys(residence);
		}
		
		//méthode sélection Code de décision (logement)
		public void selectCodDecLogement (String coddeclogement) {
			Select dropdown = new Select(CodDecLogement);
			dropdown.selectByValue(coddeclogement);
		}
}
