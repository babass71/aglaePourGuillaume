package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageVoeu0 extends SqueletteEtudiantDossier{
	private WebDriver driver;

	public PageVoeu0(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
		
	//Elements sous-partie "études"
@FindBy (id="EIdAcademie") WebElement EIdAcademie; //droplist "Académie"
@FindBy (id="EIdSecteur") WebElement EIdSecteur; //droplist "secteur"
@FindBy (id="EIdPays") WebElement EIdPays; //droplist "pays"
@FindBy (xpath="//input[@name='EUAIRNE']") WebElement EUAIRNE; //champ établissement
@FindBy (xpath="//td[@class='cellulebloc']//img[@alt='Recherche établissement']") WebElement interrogationEtablissement; //point interrogation recherche établissement
@FindBy (xpath="//input[@name='idComue']") WebElement idComue; //champ COMUE
@FindBy (id="ETypeCursus") WebElement ETypeCursus; //droplist "typeCursus"
@FindBy (id="EFormation") WebElement EFormation; //droplist "Formation"
@FindBy (id="EProgressionLMD") WebElement EProgressionLMD; //droplist "Progression LMD"
@FindBy (id="EBrancheLMD") WebElement EBrancheLMD; //droplist "BrancheLMD"
@FindBy (xpath="//input[@name='ENiveauEtudeLMD']") WebElement ENiveauEtudeLMD; //champ NiveauEtudeLMD
@FindBy (id="EIdDomaine") WebElement EIdDomaine; //droplist "Césure"
@FindBy (id="ESemestreLMD") WebElement ESemestreLMD; //droplist "SemestreLMD"
@FindBy (id="EForcageDistance") WebElement EForcageDistance; //droplist "ForcageDistance"
@FindBy (xpath="//input[@name='EDistance']") WebElement EDistance; //champ "Distance"
@FindBy (xpath="//img[@alt='Calcul distance']") WebElement interrogationDistance; //point interrogation distance

	//Elements sous-partie "logement"
@FindBy (id="LIdAcademie") WebElement LIdAcademie; //droplist "Académie"
@FindBy (id="LIdSecteur") WebElement LIdSecteur; //droplist "secteur"
@FindBy (id="LIdPays") WebElement LIdPays; //droplist "pays"
@FindBy (xpath="//input[@name='LUAIRNE']") WebElement LUAIRNE; //champ "établissement"
@FindBy (xpath="//input[@name='LUAIRNEO']") WebElement LUAIRNEO; //champ "établissement Origine"
@FindBy (id="LTypeLogement") WebElement LTypeLogement; //droplist "Type de logement"
@FindBy (id="LTypeLogementO") WebElement LTypeLogementO; //droplist "Type de logement Origine"
@FindBy (xpath="//tr/td[text()='Nombre de cohabitants']/following-sibling::td//td[1]/input") WebElement LNombreCohabitants; //droplist "Nombre de cohabitants"
@FindBy (xpath="//tr/td[text()='Nombre de cohabitants']/following-sibling::td//td[2]/input") WebElement LNombreCohabitantsO; //droplist "Nombre de cohabitants Origine"
@FindBy (id="LCategorie") WebElement LCategorie; //droplist "Catégorie"
@FindBy (id="LCategorieO") WebElement LCategorieO; //droplist "CatégorieO"
@FindBy (xpath="//td[text()='Nombre de colocataires']/following-sibling::td/input") WebElement LNombreColocataires; //champ "Nombre de Colocataires"
@FindBy (id="LForcageDecision") WebElement LForcageDecision; //droplist "Forçage Décision"
@FindBy (id="LDecision") WebElement LDecision; //droplist "Décision-date"
@FindBy (xpath="//input[@name='LDateArrivee']") WebElement LDateArrivee; //champ "Dates arrivée-départ (arrivée)"
@FindBy (xpath="//input[@name='LDateDepart']") WebElement LDateDepart; //champ "Dates arrivée-départ (départ)"

	//Elements sous-partie "Aides"
@FindBy (xpath="//A[@href='#']/img[@alt='Ajout aide']") WebElement ajoutAide; //bouton d'ajout d'aide
@FindBy (xpath="//tr[5]/td[3]/select") WebElement ACategorieAide1; //droplist "catégorie" (PREMIERE LIGNE UNIQUEMENT)
@FindBy (xpath="//tr[5]/td[4]/select") WebElement AIdAide1; //droplist "code" (PREMIERE LIGNE UNIQUEMENT)
@FindBy (xpath="//tr[5]/td[5]/select") WebElement AForcageDecision1; //droplist "forcage" (PREMIERE LIGNE UNIQUEMENT)
@FindBy (xpath="//tr[5]/td[6]/select") WebElement ADecision1; //droplist "decision" (PREMIERE LIGNE UNIQUEMENT)

	//Elements barre de validation/annulation
@FindBy (xpath="//td[@class='zoneonglet']/input[@value='Ajouter']") WebElement Ajouter; //bouton d'ajout de l'aide réclamée
@FindBy (xpath="//td[@class='zoneonglet']/input[@value='Annuler']") WebElement Annuler; //bouton d'annulation de l'aide réclamée
@FindBy (xpath="//td[@class='zoneonglet']/input[@value='Modifier']") WebElement Modifier; //bouton modification de l'aide réclamée
@FindBy (xpath="//tr[2]/td[2]/input") WebElement Supprimer;

//td[@class='zoneonglet']/input[@value='Ajouter']

	
	//Méthode remplissage de section Etudes dans Voeux
	public void remplissageVoeuEtude(WebDriver driver, String AC, String secteur, String pays, String typeCursus, String formation, String progLMD, String Eta, String Branche, String Semestre) {
		//remplir la partie "Etudes"
		selectAcademie(AC);
		selectSecteur(secteur);
		selectPays(pays);
		selectTypeCursus(typeCursus);
		selectFormation(formation);
		selectProgLMD(progLMD);
		selectEtablissement(Eta);
		selectBrancheLMD(Branche);
		selectSemetre(Semestre);
	}
	
	//Méthode remplissage de section Aides dans Voeux
	public void ajouterVoeuAides(WebDriver driver) {
		//remplir la partie "Aides"
		ajoutAide.click();
	}
	
	/* public void remplissageVoeuAidesRestreint(WebDriver driver, String categorie1, String code1) {
		//remplir la partie "Aides"
		selectCategorie1(categorie1);
		selectCode1(code1);
	} */
	
	//Méthode remplissage de section Logement dans Voeux
	public void remplissageVoeuLogement(WebDriver driver, String ACl, String secteurl, String paysl, String ResD, String LogD, String NbCohabD, String CatD, String NbColocs, String DecDat, String DateArriveeLog, String DateDepartLog) {
		//remplir la partie "Aides"
		selectAcademieLog(ACl);
		selectSecteurLog(secteurl);
		selectPaysLog(paysl);
		selectDemandeeResidence(ResD);
		selectDemandeeTypeLog(LogD);
		selectDemandeeNbCohabitants(driver, NbCohabD);
		selectDemandeeCategorie(CatD);
		selectNombreColocataires(NbColocs);
		selectDecisionDate(DecDat);
		selectDateArrivee(DateArriveeLog);
		selectDateDepart(DateDepartLog);
	}
	
	public void forcageDecisionLogement(WebDriver driver, String forcage) {
		selectForcageDecision(forcage);
	}
	
	//Méthode remplissage de section Logement dans Voeux
	public void remplissageVoeuLogementMinimal(WebDriver driver, String ACl, String secteurl, String paysl, String ResD, String TypLogD, String NbCohabD, String CatD) {
		//remplir la partie "Aides"
		selectAcademieLog(ACl);
		selectSecteurLog(secteurl);
		selectPaysLog(paysl);
		selectDemandeeResidence(ResD);
		selectDemandeeTypeLog(TypLogD);
		selectDemandeeNbCohabitants(driver, NbCohabD);
		selectDemandeeCategorie(CatD);
	}
	
	//Méthode de Forcage de la distance (partie Etudes)
	public void remplissageForcageDistance(WebDriver driver, String forcage, String distance) {		
		selectForcage(forcage);
		selectDistance(distance);
	}
	
	//Méthode validation d'un voeu
	public PagePrincipaleDSE clickAjouter(WebDriver driver) {
		Ajouter.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//Méthode Edition d'un voeu
	public PagePrincipaleDSE clickModifier(WebDriver driver) {
		Modifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//Supprimer le voeu 0
	public PagePrincipaleDSE clickSupprimer(WebDriver driver) {
		Supprimer.click();
		driver.switchTo().alert().accept();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//Annuler les modifications
	public PagePrincipaleDSE clickAnnuler(WebDriver driver) {
		Annuler.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	
	
	
	//LISTE METHODES DE LA SECTION "LOGEMENT"
		//méthode sélection Académie
		public void selectAcademieLog (String ACl) {
			Select dropdown = new Select(LIdAcademie);
			dropdown.selectByValue(ACl);
		}
		
		//méthode sélection Secteur
		public void selectSecteurLog (String secteurl) {
			Select dropdown = new Select(LIdSecteur);
			dropdown.selectByValue(secteurl);
		}
		
		//méthode sélection Pays
		public void selectPaysLog (String paysl) {
			Select dropdown = new Select(LIdPays);
			dropdown.selectByValue(paysl);
		}
		
		//méthode remplissage champ Demandée-Residence
		public void selectDemandeeResidence(String ResD) {
			LUAIRNE.sendKeys(ResD);
		}
	
		//méthode remplissage champ Origine-Residence
		public void selectOrigineResidence(String ResO) {
			LUAIRNEO.sendKeys(ResO);
		}
		
		//méthode remplissage champ Demandée-TypeLogement
		public void selectDemandeeTypeLog(String TypLogD) {
			Select dropdown = new Select(LTypeLogement);
			dropdown.selectByValue(TypLogD);
		}
	
		//méthode remplissage champ Origine-TypeLogement
		public void selectOrigineTypLog(String TypLogO) {
			Select dropdown = new Select(LTypeLogementO);
			dropdown.selectByValue(TypLogO);
		}
		
		//méthode remplissage champ Demandée-NbCohabitants
		public void selectDemandeeNbCohabitants(WebDriver driver, String NbCohabD) {
			LNombreCohabitants.clear();
			driver.switchTo().alert().accept();
			LNombreCohabitants.sendKeys(NbCohabD);
		}
	
		//méthode remplissage champ Origine-NbCohabitants
		public void selectOrigineNbCohabitants(WebDriver driver, String NbCohabO) {
			LNombreCohabitantsO.clear();
			driver.switchTo().alert().accept();
			LNombreCohabitantsO.sendKeys(NbCohabO);
		}
		
		//méthode remplissage champ Demandée-Categorie
		public void selectDemandeeCategorie(String CatD) {
			Select dropdown = new Select(LCategorie);
			dropdown.selectByValue(CatD);
		}
	
		//méthode remplissage champ Origine-Categorie
		public void selectOrigineCategorie(String CatO) {
			Select dropdown = new Select(LCategorieO);
			dropdown.selectByValue(CatO);
		}
		
		//méthode remplissage champ Nombre de colocataires
		public void selectNombreColocataires(String NbColocs) {
			LNombreColocataires.clear();
			driver.switchTo().alert().accept();
			LNombreColocataires.sendKeys(NbColocs);
		}
		
		//méthode remplissage champ Forçage Décision
		public void selectForcageDecision(String ForDec) {
			Select dropdown = new Select(LForcageDecision);
			dropdown.selectByValue(ForDec);
		}
		
		//méthode remplissage champ Décision-date
		public void selectDecisionDate(String DecDat) {
			Select dropdown = new Select(LDecision);
			dropdown.selectByValue(DecDat);
		}
		
		//méthode remplissage champ Date Arrivee
		public void selectDateArrivee(String DateArriveeLog) {
			LDateArrivee.sendKeys(DateArriveeLog);
		}
		
		//méthode remplissage champ Date Depart
		public void selectDateDepart(String DateDepartLog) {
			LDateDepart.sendKeys(DateDepartLog);
		}
		
		
		//méthode de suppression du logement
		public void suppressionLogement(WebDriver driver) {
			WebElement croixSuppression = driver.findElement(By.xpath("//td[3]//tr[3]/td/table/tbody/tr[1]/td[1]/a/img"));
			croixSuppression.click();
			driver.switchTo().alert().accept();
		}
	
	
	
//LISTE METHODES DE LA SECTION "ETUDE"
	//méthode sélection Académie
	public void selectAcademie (String AC) {
		Select dropdown = new Select(EIdAcademie);
		dropdown.selectByValue(AC);
	}
	
	//méthode sélection Secteur
	public void selectSecteur (String secteur) {
		Select dropdown = new Select(EIdSecteur);
		dropdown.selectByValue(secteur);
	}
	
	//méthode sélection Pays
	public void selectPays (String pays) {
		Select dropdown = new Select(EIdPays);
		dropdown.selectByValue(pays);
	}
	
	//méthode remplissage champ Etablissement0
	public void selectEtablissement(String Eta) {
		EUAIRNE.clear();
		EUAIRNE.sendKeys(Eta);
	}
	
	//méthode remplissage champ Etablissement0 quand le champ est encore rempli
	public void selectEtablissement2(String Eta) {
		EUAIRNE.sendKeys(Eta);
	}
	
	//méthode ouverture des listes d'établissement
	public void selectEtablissement3() {
		interrogationEtablissement.click();
		driver.switchTo().window("https://aglaestage.ac-paris.fr/aglae3/dossier/aideListeEtb.jsp?ResultEtbEtude");
		WebElement ecole = driver.findElement(By.xpath("//tr[6]/td[1]/a"));
		ecole.click();
	}
	
	//méthode sélection typedecursus
	public void selectTypeCursus (String typeCursus) {
		Select dropdown = new Select(ETypeCursus);
		dropdown.selectByValue(typeCursus);
	}
	
	//méthode sélection formation
	public void selectFormation (String formation) {
		Select dropdown = new Select(EFormation);
		dropdown.selectByValue(formation);
	}
	
	//méthode sélection ProgressionLMD
	public void selectProgLMD (String progLMD) {
		Select dropdown = new Select(EProgressionLMD);
		dropdown.selectByValue(progLMD);
	}
	
	//méthode sélection BrancheLMD
	public void selectBrancheLMD (String brancheLMD) {
		Select dropdown = new Select(EBrancheLMD);
		dropdown.selectByValue(brancheLMD);
	}
	
	//méthode remplissage champ Niveau
	public void selectNiveau(String niveau) {
		ENiveauEtudeLMD.sendKeys(niveau);
	}
	
	//méthode sélection Césure
	public void selectCesure (String cesure) {
		Select dropdown = new Select(EIdDomaine);
		dropdown.selectByValue(cesure);
	}

	//méthode sélection Semestre LMD
	public void selectSemetre (String Semestre) {
		Select dropdown = new Select(ESemestreLMD);
		dropdown.selectByValue(Semestre);
	}
	
	//méthode sélection Forçage Distance
	public void selectForcage (String forcage) {
		Select dropdown = new Select(EForcageDistance);
		dropdown.selectByValue(forcage);
	}
	
	//méthode remplissage distance forcée
	public void selectDistance(String distance) {
		//EDistance.clear();
		EDistance.sendKeys(distance);
	}
	
	
//LISTE METHODES DE LA SECTION "AIDES" (Première ligne)
	//méthode sélection d'une cellule unique dans pageVoeu (section Aide(s))
	public String selectCaseAide (int ligneAide, int colonneAide, String valueInList) {
		int ligneAideFinal = (ligneAide*3)+2;
		int colonneAideFinal = (colonneAide)+2;
		WebElement CaseDuVoeu = driver.findElement(By.xpath("//tr["+ligneAideFinal+"]/td["+colonneAideFinal+"]/select"));
		Select dropdown = new Select(CaseDuVoeu);
		dropdown.selectByValue(valueInList);
		return valueInList;
	}
	
	//méthode d'édition d'une ligne (après addition ou edition). 
	public void remplissageVoeuAidesStandard(WebDriver driver, int ligneVoeu, String categorie1, String code1) {
		selectCaseAide(ligneVoeu, 1, categorie1);
		selectCaseAide(ligneVoeu, 2, code1);
	}
	
	//méthode d'édition d'un forçage (après addition ou edition). 
	public void remplissageVoeuAidesForcage(WebDriver driver, int ligneVoeu, String forcage1, String decision1) {
		selectCaseAide(ligneVoeu, 3, forcage1);
		selectCaseAide(ligneVoeu, 4, decision1);
	}
	
	//méthode de suppression d'une demande d'aide
	public void suppressionAide(WebDriver driver, int ligneVoeu) {
		int croixVoeu = (ligneVoeu*3)+2;
		WebElement croixSuppression = driver.findElement(By.xpath("//tr[3]//tr["+croixVoeu+"]/td[1]/a/img"));
		croixSuppression.click();
		driver.switchTo().alert().accept();
	}


	//ASSERT LOGEMENT VOEU 0
	public String recupNomLogement0() {
		WebElement EtaLogement = driver.findElement(By.xpath("//tr[8]/td[2]/table/tbody/tr/td[1]"));
		String etaLogement = EtaLogement.getText();
		String[] etaLogement2 = etaLogement.split("[ ]");
		String etaLogement3 = etaLogement2[2];
		return etaLogement3;
	}
}