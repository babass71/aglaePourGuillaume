package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class MenuHorrizontal {
	public WebDriver driver;

	public MenuHorrizontal(WebDriver driver) {
		
		super();
		this.driver=driver;
		}

	public void checkElementPresent(WebDriverWait wait) {
		// TODO Auto-generated method stub
		
	}


}
