package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageLogin {
	
	public WebDriver driver;
@FindBy (name="j_username") WebElement champLogin;
@FindBy (name="j_password") WebElement champPassword;
@FindBy (name="ok") WebElement boutonValider;
@FindBy (xpath="//input[@value='Annuler']") WebElement boutonEffacer;
	
	
	public PageLogin(WebDriver driver) {
		super();
		this.driver = driver;
		}
	
	public PageDossiersGestion seConnecter(String login, String password) {
			connection(login, password);
		return PageFactory.initElements(driver, PageDossiersGestion.class);
		
	}

	public void connection(String login, String password) {
		champLogin.sendKeys(login);
		champPassword.sendKeys(password);
		boutonValider.click();
	}
}

