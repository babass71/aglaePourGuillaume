package Test_destruction;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;
import pageObject.PageDossier;
import pageObject.PageDossiersGestion;
import pageObject.PageEditions;
import pageObject.PageEtudiant;
import pageObject.PageHistorique;
import pageObject.PageInstructions;
import pageObject.PageLogin;
import pageObject.PagePaiementVoeu0;
import pageObject.PagePrincipaleDSE;
import pageObject.PageTexte;
import pageObject.PageVoeu0;
import pageObject.PageVoeuHistorique;
import pageObject.PageVoeux;
import test.FirefoxDriverSetup;
import test.ChromeDriverSetup;
import pageObject.PageHistorique;
import pageObject.CreerPageHistorique;
import pageObject.PageContact;
import utils.OutilsProjet;

public class Test2_CDT7_Firefox extends FirefoxDriverSetup{
	
	@SuppressWarnings("deprecation")
	@Test
	public void run() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		PageLogin pageLogin = PageFactory.initElements(driver, PageLogin.class);
		Properties properties = new Properties();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream("fileCasNomial.properties");
		
		LOGGER.info("---------------> Cas de test 1 : Creation d'un DSE avec donn�es maximales � Paris <---------------" );
		properties.load(file);
		String login=properties.getProperty("loginModo");
		String mdp=properties.getProperty("mdp007");
		String anneeEtudiant=properties.getProperty("annee2019");
		String INE=properties.getProperty("INERandom");
		
		String acaAssert = login.substring(0,3);
		String autoAssert = login.substring(3);
		System.out.println(acaAssert);
		System.out.println(autoAssert);
		
		LOGGER.info("Pas de test 1 : ouverture de la session avec les login "+login +" et mot de passe" + mdp );
		PageDossiersGestion pageDossiersGestion = pageLogin.seConnecter(login, mdp);
		LOGGER.info("Verification de la bonne organisation de la page d'accueil d'Aglae");
		Thread.sleep(2000);
		pageDossiersGestion.AssertAllElementsOfPageDossiersGestion(acaAssert, autoAssert);
		
		LOGGER.info("Pas de test 2 : synchronisation de la page et ajout de l'"+anneeEtudiant+" dans le champ annee et "+INE+" dans le champ INE");
		PagePrincipaleDSE pagePrincipaleDSE = pageDossiersGestion.creerEtudiant(driver, anneeEtudiant, INE);
		pagePrincipaleDSE.AssertAllElementsOfPagePrincipaleDSE();
		
		LOGGER.info("Pas de test 3 : Renseignement des informations de la section Etudiant" );
		PageEtudiant pageEtudiant= pagePrincipaleDSE.clicketudiant();
		Thread.sleep(2000);
		String INERecup = pageEtudiant.recupINE(driver);
		LOGGER.info("Recuperation de l'INE genere : " +INERecup );
		pageEtudiant.recupDate();
		LOGGER.info("Verification que la date de creation est egale a la date de modification" );
		String genre=properties.getProperty("genreMasculin");
		String nom=pageEtudiant.GenererNomAleatoire();
		String nomUsage=pageEtudiant.GenererNomAleatoire();
		String prenom=pageEtudiant.GenererNomAleatoire();
		String prenom2=pageEtudiant.GenererNomAleatoire();
		String prenom3=pageEtudiant.GenererNomAleatoire();
		String situationFamiliale=properties.getProperty("celibataire");
		String telephone=pageEtudiant.GenererTelephoneAleatoire();
		String courriel=pageEtudiant.GenererMailAleatoire();
		String dateNaissance=properties.getProperty("dateNaissance");
		String nationalite=properties.getProperty("france");
		String situationEtranger=properties.getProperty("franceAndorre");
		
		String recupINE = pageEtudiant.recupINE(driver);
		LOGGER.debug("�l�ve g�ner� avec l'INE " + recupINE);
		LOGGER.debug("�l�ve g�n�r� avec le pr�nom " + prenom);
		LOGGER.debug("�l�ve g�n�r� avec le nom " + nom);
		
		pageEtudiant.remplissageMaximal(driver, genre, nom, nomUsage, prenom, prenom2, prenom3, dateNaissance, situationFamiliale, telephone, courriel, nationalite, situationEtranger);
		//V�rifier la liste des erreurs sur la page principale apr�s remplissage d'Etudiant
		Map<String,String> actualTableauMessage = pagePrincipaleDSE.recupMapDiagnostic(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier = OutilsProjet.orderAscendingMap(actualTableauMessage);
		System.out.println(actualTableauMessageTrier);
		Map<String,String> mapReferenceMessageDossier=OutilsProjet.getMapFromFile("Diagnostics/diagnosticDossier.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier);
		System.out.println(mapReferenceMessageDossierTrier);	
		assertEquals(mapReferenceMessageDossierTrier, actualTableauMessageTrier);
		
		LOGGER.info("Pas de test 4 : Renseignement des informations de la section Dossier" );
		PageDossier pageDossier = pagePrincipaleDSE.clickdossier();
		Thread.sleep(1000);
		String rue=properties.getProperty("rue");
		String cp=properties.getProperty("cp");
		String ville=properties.getProperty("ville");
		String pays=properties.getProperty("pays");
		String AC=properties.getProperty("Valide");
		String revenus=properties.getProperty("revenus");
		pageDossier.renseignerAdresse(rue, cp, ville, pays, AC);
		pageDossier.remplirChampsRevenus(revenus);
		pageDossier.clickModifier(driver);
		//V�rifier la liste des erreurs sur la page principale apr�s remplissage du Dossier
		Map<String,String> actualTableauMessage2 = pagePrincipaleDSE.recupMapDiagnostic(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier2 = OutilsProjet.orderAscendingMap(actualTableauMessage2);
		System.out.println(actualTableauMessageTrier2);
		Map<String,String> mapReferenceMessageDossier2=OutilsProjet.getMapFromFile("Diagnostics/diagnosticDossierComplet.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier2 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier2);
		System.out.println(mapReferenceMessageDossierTrier2);	
		assertEquals(mapReferenceMessageDossierTrier2, actualTableauMessageTrier2);
		
		LOGGER.info("Pas de test 5 : Renseignement des informations de la section Contact" );
		PageContact pageContact = pagePrincipaleDSE.clickContact();
		//contact1
		String telephoneC1=pageContact.GenererTelephoneAleatoire();
		String numEtVoieC1=properties.getProperty("numEtVoieC1");
		String compAdresse1C1=properties.getProperty("compAdresse1C1");
		String compAdresse2C1=properties.getProperty("compAdresse2C1");
		String localiteC1=properties.getProperty("localiteC1");
		String paysContactC1=properties.getProperty("paysContactC1");
		String codePostalC1=properties.getProperty("codePostalC1");
		//contact2
		pageContact.remplissageContact(1, telephoneC1, numEtVoieC1, compAdresse1C1, compAdresse2C1, localiteC1, paysContactC1, codePostalC1);
		String numEtVoieC2=properties.getProperty("numEtVoieC2");
		String compAdresse1C2=properties.getProperty("compAdresse1C2");
		String compAdresse2C2=properties.getProperty("compAdresse2C2");
		String localiteC2=properties.getProperty("localiteC2");
		String paysContactC2=properties.getProperty("paysContactC2");
		String codePostalC2=properties.getProperty("codePostalC2");
		//contact3
		pageContact.remplissageContact(2, telephoneC1, numEtVoieC2, compAdresse1C2, compAdresse2C2, localiteC2, paysContactC2, codePostalC2);
		String numEtVoieC3=properties.getProperty("numEtVoieC3");
		String compAdresse1C3=properties.getProperty("compAdresse1C3");
		String compAdresse2C3=properties.getProperty("compAdresse2C3");
		String localiteC3=properties.getProperty("localiteC3");
		String paysContactC3=properties.getProperty("paysContactC3");
		String codePostalC3=properties.getProperty("codePostalC3");
		pageContact.remplissageContact(3, telephoneC1, numEtVoieC3, compAdresse1C3, compAdresse2C3, localiteC3, paysContactC3, codePostalC3);
		pageContact.clickModifier(driver);
		//Verifier les messages d'alerte
		Map<String,String> actualTableauMessage3 = pagePrincipaleDSE.recupMapDiagnostic(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier3 = OutilsProjet.orderAscendingMap(actualTableauMessage3);
		System.out.println(actualTableauMessageTrier3);
		Map<String,String> mapReferenceMessageDossier3=OutilsProjet.getMapFromFile("Diagnostics/diagnosticDossierComplet.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier3 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier3);
		System.out.println(mapReferenceMessageDossierTrier3);	
		assertEquals(mapReferenceMessageDossierTrier3, actualTableauMessageTrier3);
		
		LOGGER.info("Pas de test 6 : Renseignement des informations dans la section voeux" );
			//PREMIER VOEU
		//remplir Etudes dans voeux
		PageVoeux pageVoeux = pagePrincipaleDSE.clickVoeuxPlus(1);
		Thread.sleep(1000);
		String toto3 = pageDossier.recupNombreBloc(driver);
		LOGGER.info("comptage du nombre de bloc dans la page Voeux" );
		Assert.assertTrue("Le nombre de bloc doit �tre �gal � 3", toto3.equals("3"));
		//remplir le voeu d'�tablissement
		String ACVoeu =properties.getProperty("AcademiePARIS");
		String secteurVoeu =properties.getProperty("secteur1");
		String paysVoeu =properties.getProperty("paysFRANCE");
		String EtaVoeu =properties.getProperty("etablissementA");
		String typeCursusVoeu =properties.getProperty("cursusLMD");
		String formationVoeu =properties.getProperty("cursusLicence");
		String progLMDVoeu =properties.getProperty("Licence");
		String Branche =properties.getProperty("Sans_objet");
		String Semestre =properties.getProperty("InscriptionSemestrielle");
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu, secteurVoeu, paysVoeu, typeCursusVoeu, formationVoeu, progLMDVoeu, EtaVoeu, Branche, Semestre);
		//remplir la demande d'aide 1
		String categorieVoeu1 =properties.getProperty("Principale");
		String codeVoeu1 =properties.getProperty("BourseSurCriteresSociaux");
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 1, categorieVoeu1, codeVoeu1);
		//remplir la demande d'aide 2
		String categorieVoeu2 =properties.getProperty("Complementaire");
		String codeVoeu2 =properties.getProperty("PupilleEtat");
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 2, categorieVoeu2, codeVoeu2);
		//remplir la demande de logement
		String ACl2 =properties.getProperty("AcademieLogPARIS");
		String secteurl2 =properties.getProperty("secteurLog1");
		String paysl2 =properties.getProperty("paysLogFRANCE");
		String ResD2 =properties.getProperty("residence");
		String TypLogD2 =properties.getProperty("logementT1");
		String NbCohabD2 =properties.getProperty("1cohabitant");
		String CatD2 =properties.getProperty("logementConventionne");	
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACl2, secteurl2, paysl2, ResD2, TypLogD2, NbCohabD2, CatD2);
		//ajouter le voeu
		pageVoeux.clickAjouter(driver);
		
			//DEUXIEME VOEU
		//remplir Etudes dans voeux
		pagePrincipaleDSE.clickVoeuxPlus(2);
		Thread.sleep(1000);
		String toto4 = pageDossier.recupNombreBloc(driver);
		LOGGER.info("comptage du nombre de bloc dans la page Voeux" );
		Assert.assertTrue("Le nombre de bloc doit �tre �gal � 3", toto4.equals("3"));
		//remplir le voeu d'�tablissement
		String EtaVoeuPar =properties.getProperty("etablissementB");
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu, secteurVoeu, paysVoeu, typeCursusVoeu, formationVoeu, progLMDVoeu, EtaVoeuPar, Branche, Semestre);
		//remplir la demande d'aide 1
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 1, categorieVoeu1, codeVoeu1);
		//remplir la demande de logement
		String ACPar =properties.getProperty("AcademieLogPARIS");
		String ResPar =properties.getProperty("residence");	
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACPar, secteurl2, paysl2, ResPar, TypLogD2, NbCohabD2, CatD2);
		//ajouter le voeu
		pageVoeux.clickAjouter(driver);
		
			//TROISIEME VOEU
		//remplir Etudes dans voeux
		pagePrincipaleDSE.clickVoeuxPlus(3);
		Thread.sleep(1000);
		String EtaVoeuPar2 =properties.getProperty("etablissementG");
		String toto5 = pageDossier.recupNombreBloc(driver);
		LOGGER.info("comptage du nombre de bloc dans la page Voeux" );
		Assert.assertTrue("Le nombre de bloc doit �tre �gal � 3", toto5.equals("3"));
		//remplir le voeu d'�tablissement
		String formationVoeu2 =properties.getProperty("cursusMaster");
		String progLMDVoeu2 =properties.getProperty("Master");
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu, secteurVoeu, paysVoeu, typeCursusVoeu, formationVoeu2, progLMDVoeu2, EtaVoeuPar2, Branche, Semestre);
		//remplir la demande d'aide 1
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 1, categorieVoeu1, codeVoeu1);
		//remplir la demande d'aide 2
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 2, categorieVoeu2, codeVoeu2);
		//remplir la demande d'aide 3
		String codeVoeu3 =properties.getProperty("Merite");
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 3, categorieVoeu2, codeVoeu3);
		//remplir la demande de logement
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACl2, secteurl2, paysl2, ResD2, TypLogD2, NbCohabD2, CatD2);
		//ajouter le voeu
		pageVoeux.clickAjouter(driver);
		
			//QUATRIEME VOEU
		//remplir Etudes dans voeux
		pagePrincipaleDSE.clickVoeuxPlus(3);
		Thread.sleep(1000);
		String EtaVoeuPar3 =properties.getProperty("etablissementH");
		String toto6 = pageDossier.recupNombreBloc(driver);
		LOGGER.info("comptage du nombre de bloc dans la page Voeux" );
		Assert.assertTrue("Le nombre de bloc doit �tre �gal � 3", toto6.equals("3"));
		//remplir le voeu d'�tablissement
		String formationVoeu3 =properties.getProperty("cursusLicenceProf");
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu, secteurVoeu, paysVoeu, typeCursusVoeu, formationVoeu3, progLMDVoeu, EtaVoeuPar3, Branche, Semestre);
		//remplir la demande d'aide 1
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 1, categorieVoeu1, codeVoeu1);
		String forcage =properties.getProperty("forcageRejet");
		String decisionN =properties.getProperty("refusDepassementBareme");
		pageVoeux.remplissageVoeuAidesForcage(driver, 1, forcage, decisionN);
		//remplir la demande de logement
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACl2, secteurl2, paysl2, ResD2, TypLogD2, NbCohabD2, CatD2);
		//ajouter le voeu
		pageVoeux.clickAjouter(driver);
		
		LOGGER.info("Pas de test 7 : Creer un nouveau texte" );
		PageTexte PageTexte = pagePrincipaleDSE.clickLoupeTexte();
		String texte = properties.getProperty("texteLibre1");
		PageTexte.sendText(texte);
		PageTexte.clickModifier(driver);
		
		LOGGER.info("Pas de test 8 : Creer une nouvelle instruction" );
		PageInstructions PageInstructions = pagePrincipaleDSE.clickInstructions();
		String gestiondse = properties.getProperty("gestiondse");
		String theme = properties.getProperty("introduction");
		String introduction51 = properties.getProperty("01-51");
		PageInstructions.selectObjetCourriel(gestiondse);
		PageInstructions.selectTheme(theme);
		PageInstructions.selectInstruction(introduction51);
		PageInstructions.clickCroixInstructions();
		String theme2 = properties.getProperty("pieceDeBase");
		String manqueRIB = properties.getProperty("02-55");
		Thread.sleep(500);
		PageInstructions.selectTheme(theme2);
		PageInstructions.selectInstruction(manqueRIB);
		PageInstructions.clickCroixInstructions();
		Thread.sleep(500);
		PageInstructions.clickEnvoyerCourriel(driver);
		Map<String,String> actualTableauMessage4 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier4 = OutilsProjet.orderAscendingMap(actualTableauMessage4);
		System.out.println(actualTableauMessageTrier4);
		Map<String,String> mapReferenceMessageDossier4=OutilsProjet.getMapFromFile("Diagnostics/diagnosticCourriel.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier4 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier4);
		System.out.println(mapReferenceMessageDossierTrier4);	
		assertEquals(mapReferenceMessageDossierTrier4, actualTableauMessageTrier4);
		
		LOGGER.info("Pas de test 9 : Enregistrement du DSE" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage5 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier5 = OutilsProjet.orderAscendingMap(actualTableauMessage5);
		System.out.println(actualTableauMessageTrier5);
		Map<String,String> mapReferenceMessageDossier5=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEnregistrerDossierComplet.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier5 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier5);
		System.out.println(mapReferenceMessageDossierTrier5);	
		assertEquals(mapReferenceMessageDossierTrier5, actualTableauMessageTrier5);
		PageEditions pageEditions = pagePrincipaleDSE.clickEditions();
		String nbEditionsExpected = properties.getProperty("final2");
		String nbEditionsActual = pageEditions.recupNbNU(driver);
		assertEquals(nbEditionsExpected, nbEditionsActual);
		pageEditions.clickFermer(driver);
		
		LOGGER.info("Pas de test 10 : Verification de l'historique" );
		PageHistorique pageHistorique = pagePrincipaleDSE.clickHistorique();
		pageHistorique.AssertPresenceUneLigne();
		pageHistorique.clickFermerHistorique();
		
		
		LOGGER.info("---------------> Cas de test 2 : Creation d'un DSE avec donn�es maximales en Nouvelle-Cal�donie <---------------" );
		LOGGER.info("Pas de test 1 : Verification qu'affecter un logement sur un secteur particulier se r�percute sur les autres voeux dans le m�me secteur" );
		pagePrincipaleDSE.clickVoeuxEditer(1);
		String logementAffecte = properties.getProperty("affectation10");
		pageVoeux.selectDecisionDate(logementAffecte);
		pageVoeux.clickModifier(driver);
		pagePrincipaleDSE.verifStatutFsurLigneVoeuChoisie(3);
		pagePrincipaleDSE.verifStatutFsurLigneVoeuChoisie(4);
		
		LOGGER.info("Pas de test 2 : Enregistrement du DSE" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage6 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier6 = OutilsProjet.orderAscendingMap(actualTableauMessage6);
		System.out.println(actualTableauMessageTrier6);
		Map<String,String> mapReferenceMessageDossier6=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier6 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier6);
		System.out.println(mapReferenceMessageDossierTrier6);	
		assertEquals(mapReferenceMessageDossierTrier6, actualTableauMessageTrier6);
		
		
		LOGGER.info("---------------> Cas de test 3 : Test de changement de l'ordre des voeux <---------------" );
		LOGGER.info("Pas de test 1 : Changer l'ordre des voeux et v�rifier" );
		//R�cup�rer les informations de la section Etudes des voeux
		String VoeuEtude1Base = pagePrincipaleDSE.recupContenuTextuelEtude(1);
		String VoeuEtude2Base = pagePrincipaleDSE.recupContenuTextuelEtude(2);
		String VoeuEtude3Base = pagePrincipaleDSE.recupContenuTextuelEtude(3);
		String VoeuEtude4Base = pagePrincipaleDSE.recupContenuTextuelEtude(4);
		System.out.println(VoeuEtude1Base);	
		System.out.println(VoeuEtude2Base);	
		System.out.println(VoeuEtude3Base);	
		System.out.println(VoeuEtude4Base);	
		//Cliquer sur les fl�ches de d�placement des voeux
		pagePrincipaleDSE.deplacerVoeuHaut(2);
		pagePrincipaleDSE.deplacerVoeuBas(3);
		//R�cup�rer les informations de la section Etudes des voeux (apr�s les clics sur les fl�ches)
		String VoeuEtude1Final = pagePrincipaleDSE.recupContenuTextuelEtude(1);
		String VoeuEtude2Final = pagePrincipaleDSE.recupContenuTextuelEtude(2);
		String VoeuEtude3Final = pagePrincipaleDSE.recupContenuTextuelEtude(3);
		String VoeuEtude4Final = pagePrincipaleDSE.recupContenuTextuelEtude(4);
		//Faire les assertions apr�s les changements d'ordre des voeux
		assertEquals(VoeuEtude1Base, VoeuEtude2Final);
		assertEquals(VoeuEtude2Base, VoeuEtude1Final);
		assertEquals(VoeuEtude3Base, VoeuEtude4Final);
		assertEquals(VoeuEtude4Base, VoeuEtude3Final);
		
		LOGGER.info("Pas de test 2 : Verification de l'historique" );
		//R�cuperer le nom de l'universit� du Voeu 1
		String ligne3Voeu1colonne2 = pagePrincipaleDSE.recupVoeu(1, 2, 3);
		String[] universiteVoeu1 = ligne3Voeu1colonne2.split(" - ");
		//Ouvrir historique, recuperer le nom de l'universite dans l'historique
		pagePrincipaleDSE.clickHistorique();
		String universiteHistoriqueDepart = pageHistorique.recupUniversiteVoeu(1);
		String[] universiteHistorique = universiteHistoriqueDepart.split(" - ");
		//Faire l'assertion entre le voeu1 et l'historique
		assertEquals(universiteVoeu1[1], universiteHistorique[1]);
		//Fermer la page
		pageHistorique.clickFermerHistorique();
		
		LOGGER.info("Pas de test 3 : Enregistrement et fermeture du DSE" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage7 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier7 = OutilsProjet.orderAscendingMap(actualTableauMessage7);
		System.out.println(actualTableauMessageTrier7);
		Map<String,String> mapReferenceMessageDossier7=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier7 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier7);
		System.out.println(mapReferenceMessageDossierTrier7);	
		assertEquals(mapReferenceMessageDossierTrier7, actualTableauMessageTrier7);
		Thread.sleep(1000);
		//M�thode pour r�cup�rer l'INE du dossier actuel avant de quitter
		String INE2=pagePrincipaleDSE.INEdossier(driver);
		pagePrincipaleDSE.QuitterDossierValide();
		
		
		LOGGER.info("---------------> Cas de test 4 : Proc�der � la mise en paiement d'un voeu et v�rifier les informations modifi�es par cette action <---------------" );
		LOGGER.info("Pas de test 1 : Mettre en paiement le voeu n�3" );
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.clickMisePaiement(3);
		
		LOGGER.info("Pas de test 2 : Contr�le des arr�t�s sp�cifiques � chaque aide" );
		//Ouvrir l'aide 1 du voeu 0
		PagePaiementVoeu0 PagePaiementVoeu0 = pagePrincipaleDSE.OuvrirAidePaiement(1);
		PagePaiementVoeu0.assertArrete();
		System.out.println("Assertion statut de l'arrete correct");
		LOGGER.info("Assertion statut de l'arrete correct");
		PagePaiementVoeu0.cliquerModifier();
		//Ouvrir l'aide 2 du voeu 0
		pagePrincipaleDSE.OuvrirAidePaiement(2);
		PagePaiementVoeu0.assertArrete();
		System.out.println("Assertion statut de l'arrete correct");
		LOGGER.info("Assertion statut de l'arrete correct");
		PagePaiementVoeu0.cliquerModifier();
		//Ouvrir l'aide 3 du voeu 0
		pagePrincipaleDSE.OuvrirAidePaiement(3);
		PagePaiementVoeu0.assertArrete();
		System.out.println("Assertion statut de l'arrete correct");
		LOGGER.info("Assertion statut de l'arrete correct");
		PagePaiementVoeu0.cliquerModifier();
		
		LOGGER.info("Pas de test 3 : Contr�le des lignes de cr�ance sp�cifiques � chaque aide" );
		//Ouvrir l'aide 1 du voeu 0
		pagePrincipaleDSE.OuvrirAidePaiement(1);
		PagePaiementVoeu0.verifElementsPaiements();
		System.out.println("Le masque est conforme � l'attendu");
		LOGGER.info("Le masque est conforme � l'attendu");
		PagePaiementVoeu0.cliquerModifier();
		//Ouvrir l'aide 2 du voeu 0
		pagePrincipaleDSE.OuvrirAidePaiement(2);
		PagePaiementVoeu0.verifElementsPaiements();
		System.out.println("Le masque est conforme � l'attendu");
		LOGGER.info("Le masque est conforme � l'attendu");
		PagePaiementVoeu0.cliquerModifier();
		//Ouvrir l'aide 3 du voeu 0
		pagePrincipaleDSE.OuvrirAidePaiement(3);
		PagePaiementVoeu0.verifElementsPaiements();
		System.out.println("Le masque est conforme � l'attendu");
		LOGGER.info("Le masque est conforme � l'attendu");
		PagePaiementVoeu0.cliquerModifier();
		
		LOGGER.info("Pas de test 4 : Verifier que le CV est rebas� sur le voeu 0" );
		String aideBourse1 = pagePrincipaleDSE.sauvegardeBourseVoeu0(1);
		String aideCode1 = pagePrincipaleDSE.sauvegardeCodeVoeu0(1);
		pagePrincipaleDSE.clickHistorique();
		String aideBourseH1 = pageHistorique.VerifierBourseAideHistorique(1);
		String aideCodeH1 = pageHistorique.VerifierCodeAideHistorique(1);
		assertEquals(aideBourse1,aideBourseH1);
		assertEquals(aideCode1,aideCodeH1);
		PageVoeuHistorique pageVoeuHistorique = pageHistorique.OuvrirVoeuDansHistorique(1);
		pageVoeuHistorique.clickAnnulerVoeuHistorique();
		pageHistorique.clickFermerHistorique();
		
		LOGGER.info("Pas de test 5 : Enregistrer le DSE" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage8 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier8 = OutilsProjet.orderAscendingMap(actualTableauMessage8);
		System.out.println(actualTableauMessageTrier8);
		Map<String,String> mapReferenceMessageDossier8=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier8 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier8);
		System.out.println(mapReferenceMessageDossierTrier8);	
		assertEquals(mapReferenceMessageDossierTrier8, actualTableauMessageTrier8);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		
		
		LOGGER.info("---------------> Cas de test 5 : Proc�der � la mise en logement d'un voeu et v�rifier les informations modifi�es par cette action <---------------" );
		LOGGER.info("Pas de test 1 : Mettre en logement le voeu n�3" );
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.clickMiseLogement(3);
		
		LOGGER.info("Pas de test 2 : Verification de la mise en logement du voeu 0" );
		String logVoeu0A = pagePrincipaleDSE.sauvegardeLogementVoeu0();
		PageVoeu0 pageVoeu0 = pagePrincipaleDSE.OuvrirVoeu0();
		String logVoeu0B = pageVoeu0.recupNomLogement0();
		System.out.println(logVoeu0A);
		System.out.println(logVoeu0B);
		assertEquals(logVoeu0A, logVoeu0B);
		pageVoeu0.clickAnnuler(driver);
		
		LOGGER.info("Pas de test 3 : Enregistrement du DSE" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage9 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier9 = OutilsProjet.orderAscendingMap(actualTableauMessage9);
		System.out.println(actualTableauMessageTrier9);
		Map<String,String> mapReferenceMessageDossier9=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier9 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier9);
		System.out.println(mapReferenceMessageDossierTrier9);	
		assertEquals(mapReferenceMessageDossierTrier9, actualTableauMessageTrier9);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		
		
		LOGGER.info("---------------> Cas de test 6 : Quitter un DSE et le rouvrir <---------------" );
		LOGGER.info("Pas de test 1 : Rouvrir, enregistrer et quitter le DSE" );
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage10 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier10 = OutilsProjet.orderAscendingMap(actualTableauMessage10);
		System.out.println(actualTableauMessageTrier10);
		Map<String,String> mapReferenceMessageDossier10=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier10 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier10);
		System.out.println(mapReferenceMessageDossierTrier10);	
		assertEquals(mapReferenceMessageDossierTrier10, actualTableauMessageTrier10);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		
		
		LOGGER.info("---------------> Cas de test 7 : Supprimer les voeux uns � uns et contr�ler l'impact en base <---------------" );
		LOGGER.info("Pas de test 1 : Ouvrir et �diter le voeu n�1 (supprimer la seule aide)" );
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.clickVoeuxEditer(1);
		pageVoeux.supprimerUneAide(driver, 1);
		pageVoeux.clickModifier(driver); 
		//V�rifier que la deuxi�me ligne d'aide a �t� supprim�e sur la page principale
		String aide2Vide = pagePrincipaleDSE.recupVoeu(1, 5, 2);
		assertEquals(aide2Vide," ");
		System.out.println("l'aide principale (et unique) du voeu n�1 a bien �t� supprim�e");
		
		LOGGER.info("Pas de test 2 : Enregistrement, fermeture puis r�ouverture du dossier" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage11 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier11 = OutilsProjet.orderAscendingMap(actualTableauMessage11);
		System.out.println(actualTableauMessageTrier11);
		Map<String,String> mapReferenceMessageDossier11=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier11 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier11);
		System.out.println(mapReferenceMessageDossierTrier11);	
		assertEquals(mapReferenceMessageDossierTrier11, actualTableauMessageTrier11);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		
		LOGGER.info("Pas de test 3 :  Ouvrir et �diter le voeu n�2 (supprimer une aide)" );
		pagePrincipaleDSE.clickVoeuxEditer(2);
		pageVoeux.supprimerUneAide(driver, 2);
		pageVoeux.clickModifier(driver); 
		//V�rifier que la deuxi�me ligne d'aide a �t� supprim�e sur la page principale
		String aide3Vide = pagePrincipaleDSE.recupVoeu(2, 5, 3);
		assertEquals(aide3Vide," ");
		System.out.println("l'aide complementaire du voeu n�2 a bien �t� supprim�e");
		
		LOGGER.info("Pas de test 4 : Enregistrement, fermeture puis r�ouverture du dossier" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage12 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier12 = OutilsProjet.orderAscendingMap(actualTableauMessage12);
		System.out.println(actualTableauMessageTrier12);
		Map<String,String> mapReferenceMessageDossier12=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier12 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier12);
		System.out.println(mapReferenceMessageDossierTrier12);	
		assertEquals(mapReferenceMessageDossierTrier12, actualTableauMessageTrier12);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		
		LOGGER.info("Pas de test 5 :  Ouvrir et �diter le voeu n�3 (supprimer la demande de logement)" );
		pagePrincipaleDSE.clickVoeuxEditer(3);
		pageVoeux.deleteDemandeLogement();
		pageVoeux.clickModifier(driver); 
		//V�rifier que la demande de logement a �t� supprim�e sur la page principale
		String aide4Vide = pagePrincipaleDSE.recupVoeu(3, 3, 1);
		assertEquals(aide4Vide," ");
		System.out.println("l'aide complementaire du voeu n�3 a bien �t� supprim�e");
		
		LOGGER.info("Pas de test 6 : Enregistrement, fermeture puis r�ouverture du dossier" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage13 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier13 = OutilsProjet.orderAscendingMap(actualTableauMessage13);
		System.out.println(actualTableauMessageTrier13);
		Map<String,String> mapReferenceMessageDossier13=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier13 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier13);
		System.out.println(mapReferenceMessageDossierTrier13);	
		assertEquals(mapReferenceMessageDossierTrier13, actualTableauMessageTrier13);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		
		LOGGER.info("Pas de test 7 : Ouvrir et �diter le voeu n�4 (supprimer la seule aide forc�e)" );
		pagePrincipaleDSE.clickVoeuxEditer(4);
		pageVoeux.supprimerUneAide(driver, 1);
		pageVoeux.clickModifier(driver); 
		//V�rifier que la deuxi�me ligne d'aide a �t� supprim�e sur la page principale
		String aide5Vide = pagePrincipaleDSE.recupVoeu(4, 5, 2);
		assertEquals(aide5Vide," ");
		System.out.println("l'aide principale (et unique, forc�e) du voeu n�4 a bien �t� supprim�e");
		
		LOGGER.info("Pas de test 8 : Enregistrement, fermeture puis r�ouverture du dossier" );
		pagePrincipaleDSE.CaseCocherNU();
		pagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage14 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier14 = OutilsProjet.orderAscendingMap(actualTableauMessage14);
		System.out.println(actualTableauMessageTrier14);
		Map<String,String> mapReferenceMessageDossier14=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier14 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier14);
		System.out.println(mapReferenceMessageDossierTrier14);	
		assertEquals(mapReferenceMessageDossierTrier14, actualTableauMessageTrier14);
		Thread.sleep(1000);
		pagePrincipaleDSE.QuitterDossierValide();
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
	}

	/***
	 * 
	 * @param pagePrincipaleDSE (ne pas changer, pr�chargement de la pageobject indispensable)
	 * @param rangVoeu (num�ro du voeu � renseigner, donc rang 1, 2 ou 3 etc...)
	 * @param colonneVoeu (num�ro de la colonne � renseigner, /!\Les colonnes vides doivent �tre compt�es : 2 Pour Etude, 3 Pour Logement, 5 Pour Aide(s), 7 pour Actions))
	 * @param ligneVoeu (num�ro la ligne du voeu (ex, pour �tude, c'est 1 pour acad�mie, 2 pour cursus et 3 pour l'�tablissement) : Rien � faire � part renseigner l'int ligneVoeu)
	 * @param numeroFichierProperties (num�ro du fichier de properties � charger contenant les strings attendues)
	 * @throws IOException
	 */
	public void VerifierRemplissageVoeux (PagePrincipaleDSE pagePrincipaleDSE, int rangVoeu, int colonneVoeu, int ligneVoeu, int numeroFichierProperties) throws IOException {
		Properties voeuxProperties = new Properties();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream("fileVoeuxProperties"+numeroFichierProperties+".properties");
		voeuxProperties.load(file);
		String VoeuRangColonneLigneExpected =voeuxProperties.getProperty("VoeuRang"+rangVoeu+"Colonne"+colonneVoeu+"Ligne"+ligneVoeu+"Expected");
		String VoeuRangColonneLigneActual =pagePrincipaleDSE.recupVoeu(+rangVoeu, +colonneVoeu, +ligneVoeu);
		System.out.println(VoeuRangColonneLigneActual);
		System.out.println(VoeuRangColonneLigneExpected);
		assertEquals(VoeuRangColonneLigneExpected, VoeuRangColonneLigneActual);
	}
	

		

		

	
}
