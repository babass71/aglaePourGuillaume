package pageObject;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageTexte extends SqueletteEtudiantDossier{
	
	public PageTexte(WebDriver driver) {
		
		super(driver);
		}
	@FindBy (xpath="//textarea") WebElement champTexteLibre;
	@FindBy (xpath="//tr[4]/td/table/tbody/tr[2]/td[1]/input[1]") WebElement btnModifier;
	@FindBy (xpath="//tr[4]/td/table/tbody/tr[2]/td[1]/input[2]") WebElement btnAnnuler;
	
	public PagePrincipaleDSE clickAnnuler (WebDriver driver) {
		btnAnnuler.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public PagePrincipaleDSE clickModifier (WebDriver driver) {
		btnModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public void sendText (String text) {
		champTexteLibre.sendKeys(text);
	}
}
