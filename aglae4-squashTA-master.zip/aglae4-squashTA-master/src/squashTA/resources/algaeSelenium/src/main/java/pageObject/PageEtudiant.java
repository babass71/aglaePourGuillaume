package pageObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

import java.util.*;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy; 
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.UnexpectedTagNameException;

public class PageEtudiant extends SqueletteEtudiantDossier{
	private WebDriver driver;
	
@FindBy (id="titreCivilite") WebElement listeCivilite;
@FindBy (xpath="//input[@name='nom']") WebElement champNom;
@FindBy (xpath="//input[@name='nom2']") WebElement champNomUsage;
@FindBy (xpath="//input[@name='prenom']") WebElement champPrenom;
@FindBy (xpath="//input[@name='prenom2']") WebElement champPrenom2;
@FindBy (xpath="//input[@name='prenom3']") WebElement champPrenom3;
@FindBy (xpath="//input[@name='dateNaissance']") WebElement champDateNaissance;
@FindBy (id="situationFamille") WebElement listeSituationFamiliale;
@FindBy (xpath="//input[@name='telephone']") WebElement champTelephone;
@FindBy (xpath="//input[@name='courriel']") WebElement champCourriel;
@FindBy (id="idPays") WebElement listeNationalite;
@FindBy (id="situationEtranger") WebElement listeSituationEtranger;

@FindBy (xpath="//td[1]/table[1]/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/b") WebElement INEGenere;

@FindBy (xpath="//td[1]/table[2]//tr[3]/td[2]") WebElement DateCreation;
@FindBy (xpath="//td[1]/table[2]//tr[4]/td[2]") WebElement DateModification;

public PageEtudiant(WebDriver driver) {
		
		super(driver);
		}
	/**
	 * remplissage des differents parametres:
	 * @param civiliteRL value :
	 *  1 - Monsieur   
	 *  2 - Madame
	 * @param civiliteRL value :
	 *  1 - Etudiant
	 *  2 - Père
	 *  3 - Mère
	 *  4 - Tuteur
	 *  5 - Tutrice
	 *  6 - DDASS
	 */

	//Méthode de comparaison des dates
	public void recupDate () {
		String dateCrea = DateCreation.getText();
		String dateModif = DateModification.getText();
		assertEquals(dateCrea, dateModif);
	}
	
	public void NbBlocsEtudiant() {
		String NbBlocs = recupNombreBloc(driver);
		assertEquals(NbBlocs, "5");
	}
	
	//Méthode d'exécution d'un vidage des informations
	public void supprimerContenuDesChamps(WebDriver driver) {
		selectCivilite("");
		champNom.clear();
		champNomUsage.clear();
		champPrenom.clear();
		champPrenom2.clear();
		champPrenom3.clear();
		champDateNaissance.clear();
		selectSituationFamiliale("");
		champCourriel.clear();
		selectNationalite("");
		selectSituationEtranger("");
		boutonmModifier.click();
	}

	//Méthode d'exécution d'un remplissage maximal 
	public PagePrincipaleDSE remplissageMaximal(WebDriver driver, String genre, String nom, String nomUsage, String prenom, String prenom2, String prenom3, String dateNaissance, String situationFamiliale, String telephone, String courriel, String nationalite, String situation) {
		selectCivilite(genre);
		remplirChampNom(nom);
		remplirChampNomUsage(nomUsage);
		remplirChampPrenom(prenom);
		remplirChampPrenom2(prenom2);
		remplirChampPrenom3(prenom3);
		remplirChampDateNaissance(dateNaissance);
		selectSituationFamiliale(situationFamiliale);
		remplirChampTelephone(telephone);
		remplirChampCourriel(courriel);
		selectNationalite(nationalite);
		selectSituationEtranger(situation);
		boutonmModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}

	//Méthode d'exécution d'un remplissage minimal (civilité, nom, prénom, DOB et courriel)
	public PagePrincipaleDSE remplissageMinimal(WebDriver driver, String genre, String nom, String prenom, String dateNaissance, String situationFamiliale, String courriel, String nationalite, String situation) {
		selectCivilite(genre);
		remplirChampNom(nom);
		remplirChampPrenom(prenom);
		remplirChampDateNaissance(dateNaissance);
		selectSituationFamiliale(situationFamiliale);
		remplirChampCourriel(courriel);
		selectNationalite(nationalite);
		selectSituationEtranger(situation);
		boutonmModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//Méthode pour récupérer l'INE créé aléatoirement
	public String recupINE (WebDriver driver) {
		WebElement INECreeElement = driver.findElement(By.xpath("//td[1]/table[1]/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/b"));
		String INECreeString = INECreeElement.getText();
		return INECreeString;
	}
	
	//méthode pour génerer prénom/nom aléatoire
	public String GenererNomAleatoire() {
			int length = 7;
			boolean useLetters = true;
			boolean useNumbers = false;
			String generatedStringBrute = RandomStringUtils.random(length, useLetters, useNumbers);
			String generatedString = generatedStringBrute.toLowerCase();
			return generatedString;
	}
	
	//méthode pour génerer courriel d'élève aléatoire
	public String GenererMailAleatoire () {
		int length = 5;
		boolean useLetters = true;
		boolean useNumbers = true;
		String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
		generatedString = generatedString.toLowerCase();
		String generatedString2 = RandomStringUtils.random(length, useLetters, useNumbers);
		generatedString2 = generatedString2.toLowerCase();
		String generatedmail = generatedString + "." + generatedString2 + "@yop.com";
		return generatedmail;
	}
	
	//méthode pour génerer telephone aléatoire
	public String GenererTelephoneAleatoire () {
		int length = 8;
		boolean useLetters = false;
		boolean useNumbers = true;
		String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
		generatedString = generatedString.toLowerCase();
		String generatedtelephone = "06" + generatedString;
		return generatedtelephone;
	}
	
	/**
	 * valeur possible de la selection de civilite de l'etudiant
	 * 1 - Monsieur
	 * 2 - Madame
	 * @param civiliteRL value :1 - Monsieur / 2 - Madame
	 */
	public void selectCivilite (String genre) {
		Select dropdown = new Select(listeCivilite);
		dropdown.selectByValue(genre);	
	}
	
	//méthode remplissage champ nom
	public void remplirChampNom(String nom) {
		champNom.sendKeys(nom);
	}
	
	//méthode remplissage champ nom d'usage
	public void remplirChampNomUsage(String nomUsage) {
		champNomUsage.sendKeys(nomUsage);
	}
	
	//méthode remplissage champ prénom
	public void remplirChampPrenom(String prenom) {
		champPrenom.sendKeys(prenom);
	}
	
	//méthode remplissage champ prénom2
	public void remplirChampPrenom2(String prenom2) {
		champPrenom2.sendKeys(prenom2);
	}
	
	//méthode remplissage champ prénom3
	public void remplirChampPrenom3(String prenom3) {
		champPrenom3.sendKeys(prenom3);
	}
	
	//méthode remplissage champ date de naissance (doit être écrit sur le modèle "jj/mm/aaaa")
	public void remplirChampDateNaissance(String dateNaissance) {
		champDateNaissance.sendKeys(dateNaissance);
	}
	
	//méthode sélection de la situation familiale
	public void selectSituationFamiliale(String situationFamilialeStr) {
		Select dropdown = new Select(listeSituationFamiliale);
		dropdown.selectByValue(situationFamilialeStr);	
	}
	
	//méthode remplissage champ Telephone
	public void remplirChampTelephone(String telephone) {
		champTelephone.sendKeys(telephone);
	}
	
	//méthode remplissage champ courriel (doit contenir un @ et un .com/.fr etc pour être valide)
	public void remplirChampCourriel(String courriel) {
		champCourriel.sendKeys(courriel);
	}
	
	//méthode remplissage Nationalite
	public void selectNationalite(String situationNationaliteStr) {
		Select dropdown = new Select(listeNationalite);
		dropdown.selectByValue(situationNationaliteStr);	
	}
	
	//méthode remplissage Situation etranger
	public void selectSituationEtranger(String situationEtrangerStr) {
		Select dropdown = new Select(listeSituationEtranger);
		dropdown.selectByValue(situationEtrangerStr);	
	}
	
/************************************************************************/
//  Partie representant legal                              //
/************************************************************************/

	@FindBy (id="qualiteRL") WebElement listeQualiteRL;
	@FindBy (id="civiliteRL") WebElement listeCiviliteRL;
	@FindBy (name="nomRL") WebElement champNomRL;
	@FindBy (name="prenomRL") WebElement champPrenomRL;

//méthode remplissage champ nomRL
	public void remplirChampNomRL(String nomRL) {
		champNomRL.sendKeys(nomRL);
	}
//méthode remplissage champ nomRL
	public void remplirChampPrenomRL(String nomRL) {
		champPrenomRL.sendKeys(nomRL);
	}
	/**
	 * valeur possible de la selection de ciivte pour responsable legal
	 * 1 - Monsieur
	 * 2 - Madame
	 * @param civiliteRL value :
	 *  1 - Monsieur   
	 *  2 - Madame
	 */
	public void selectCiviliteRL (String civiliteRL) {
		Select dropdown = new Select(listeCiviliteRL);
		dropdown.selectByVisibleText(civiliteRL);;
	}
	/**
	 * valeur possible de la selection de la qualite pour responsable legal
	 *  1 - Etudiant
	 *  2 - Père
	 *  3 - Mère
	 *  4 - Tuteur
	 *  5 - Tutrice
	 *  6 - DDASS
	 * @param civiliteRL value :
	 *  1 - Etudiant
	 *  2 - Père
	 *  3 - Mère
	 *  4 - Tuteur
	 *  5 - Tutrice
	 *  6 - DDASS
	 */
	public void selectQualiteRL (String qualiteRL) {
		Select dropdown = new Select(listeQualiteRL);
		dropdown.selectByVisibleText(qualiteRL);;
	}
	
/************************************************************************/
//  Partie justificatif                            //
/************************************************************************/
//id
	@FindBy (id="crousJD") WebElement listeCrousJD;
	@FindBy (id="crousRetraite") WebElement listeCrousRetraite;
	@FindBy (id="crousOrphelin") WebElement listeCrousOrphelin;
	@FindBy (id="crousDDASS") WebElement listeCrousDDASS;
	@FindBy (id="crousDecesMere") WebElement listeCrousDecesMere;
	@FindBy (id="crousDecesPere") WebElement listeCrousDecesPere;
	@FindBy (id="crousTitreSejour") WebElement listeCrousTitreSejour;
//name
	@FindBy (name="dateJugement") WebElement champDateJugement;
	@FindBy (name="dateDebutRetraite") WebElement champDateDebutRetraite;
	@FindBy (name="dateDecesMere") WebElement champDateDecesMere;
	@FindBy (name="dateDecesPere") WebElement champDateDecesPere;
	@FindBy (name="dateDebutTitreSejour") WebElement champDateDebutTitreSejour;
	@FindBy (name="dateFinTitreSejour") WebElement champDateFinTitreSejour;
	
	/**
	 * Selection d'une liste deroulante crous  dans l'encart Justificatif les valeur de value sont
	 * @param value value : AIX AMI ANT BES BOR CAE CAL COR CRE DJI GRE LIL LYO MAY MON NCY NIC ORL POI POL REI REN REU STR TOU VER
	 * @param element value : listeCrousJD listeCrousRetraite listeCrousOrphelin listeCrousDDASS listeCrousDecesMere listeCrousDecesPere champDateDebutTitreSejour champDateFINTitreSejour
	 */
	public void selectCrous (WebElement element, String value) {
		Select dropdown = new Select(element);
		dropdown.selectByValue(value);
		
	}
	public void selectAllCrousDefaultDateDefaultCrous() {
		String test1 = "AIX";
		String dateDefaut = "01/01/2019";
		selectCrous(listeCrousJD, test1);
		selectCrous(listeCrousRetraite, test1);
		selectCrous(listeCrousOrphelin, test1);
		selectCrous(listeCrousDDASS, test1);
		selectCrous(listeCrousDecesMere, test1);
		selectCrous(listeCrousDecesPere, test1);
		selectCrous(listeCrousTitreSejour, test1);
		champDateJugement.sendKeys(dateDefaut);
		champDateDebutRetraite.sendKeys(dateDefaut);
		champDateDecesMere.sendKeys(dateDefaut);
		champDateDecesPere.sendKeys(dateDefaut);
		champDateDebutTitreSejour.sendKeys(dateDefaut);
		champDateFinTitreSejour.sendKeys(dateDefaut);
	}
	
	
	
	/************************************************************************/
	//  Assertion des messages d'erreur                                     //
	/************************************************************************/
	
  	//Méthode pour vérifier la liste de messages d'erreur affichés par rapport à une liste attendue
	public Map<String, String> recupMapDiagnostic(WebDriver driver) {
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}
}
