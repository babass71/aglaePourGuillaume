package pageObject;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageDossier extends SqueletteEtudiantDossier{
	
	public PageDossier(WebDriver driver) {
		
		super(driver);
		}
	@FindBy (id="activation") WebElement listeActivationDossier;
	@FindBy (xpath="//input[@class='bouton'][@value='Modifier']") WebElement boutonModifier;
	@FindBy (xpath="//input[@id='RGB']") WebElement champRGB;
	@FindBy (xpath="//input[@id='RFR']") WebElement champRFR;
	@FindBy (xpath="//input[@name='primoEntrant']") WebElement casePrimoEntrant;
	
/**
 * dans le cadre d'une actuvation le paramètre a mettre est V
 * @param element
 * @param value A D E L O P T V 
 */
	public void selectStatusDossier (String AC) {
		Select dropdown = new Select(listeActivationDossier);
		dropdown.selectByValue(AC);
		
	}
	
	public void selectPrimoEntrant () {
		casePrimoEntrant.click();
	}
	
	//méthode remplissage champ rue
	public void remplirChampsRevenus(String revenus) {
		champRGB.clear();
		champRGB.sendKeys(revenus);
		champRFR.clear();
		champRFR.sendKeys(revenus);
	}

	
	/**********************************************************/
	/*                 partie Adresse                         */
	/**********************************************************/
	@FindBy (name="adresseVoie") WebElement champRue;
	@FindBy (name="adresseCodePostal") WebElement champCodePostal;
	@FindBy (name="adresseLocalite") WebElement champVille;
	@FindBy (id="idPaysAdresse") WebElement listePays;
	
	//méthode remplissage champ rue
	public void remplirChampRue(String rue) {
		champRue.sendKeys(rue);
	}
	
	//méthode remplissage champ cp
	public void remplirChampCP(String cp) {
		champCodePostal.sendKeys(cp);
	}
	
	//méthode remplissage champ champVille
	public void remplirChampVille(String ville) {
		champVille.sendKeys(ville);
	}
	
	//méthode remplissage champ Pays
	public void selectPays (String pays) {
		Select dropdown = new Select(listePays);
		dropdown.selectByValue(pays);	
	}
	
	//méthode click bouton modifier
	public PagePrincipaleDSE clickModifier(WebDriver driver) {
		boutonmModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	//renseigner la section adresse
	public void renseignerAdresse(String rue, String cp, String ville, String pays, String AC) {
		remplirChampRue(rue);
		remplirChampCP(cp);
		remplirChampVille(ville);
		selectPays(pays);
		selectStatusDossier(AC);
	}
	
	
	/************************************************************************/
	//  Assertion des messages d'erreur                                     //
	/************************************************************************/
	
	//vider tous les champs de la page
	public void clearChampsDossier(WebDriver driver) {
		champRue.clear();
		champCodePostal.clear();
		champVille.clear();
		selectPays("");
		champRGB.clear();
		champRFR.clear();
		selectStatusDossier("");
		boutonmModifier.click();
	}
	
  	//Méthode pour vérifier la liste de messages d'erreur affichés par rapport à une liste attendue
	public Map<String, String> recupMapDiagnostic(WebDriver driver) {
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
	}
}
