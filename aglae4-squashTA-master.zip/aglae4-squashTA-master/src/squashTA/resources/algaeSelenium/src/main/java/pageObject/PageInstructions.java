package pageObject;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageInstructions extends SqueletteEtudiantDossier{
	
	public PageInstructions(WebDriver driver) {
		
		super(driver);
		}
@FindBy (xpath="//tr[3]//tr[4]//tr[1]/td[2]/select") WebElement champObjetCourriel;
@FindBy (xpath="//tr[3]//tr[4]//tr[3]/td[2]/select") WebElement champTheme;
@FindBy (xpath="//tr[3]//tr[4]//tr[3]/td[3]/select") WebElement champInstruction;
@FindBy (xpath="//tr[3]//tr[4]//tr[3]/td[3]/a/img") WebElement croixInstruction;
@FindBy (xpath="//textarea") WebElement champTexte;
@FindBy (xpath="//tr[4]//tr[2]/td[1]/input[1]") WebElement btnEnvoyerCourriel;
@FindBy (xpath="//tr[4]//tr[2]/td[1]/input[2]") WebElement btnNotifier;
@FindBy (xpath="//tr[4]//tr[2]/td[1]/input[3]") WebElement btnAnnuler;
@FindBy (xpath="//tr[4]//tr[2]/td[2]/input[1]") WebElement btnPurger;
	

	//Méthoe de sélection des options (menu déroulant)
	public void selectObjetCourriel (String objetCourriel) {
		Select dropdown = new Select(champObjetCourriel);
		dropdown.selectByValue(objetCourriel);
	}

	public void selectTheme (String theme) {
		Select dropdown = new Select(champTheme);
		dropdown.selectByValue(theme);
	}
	
	public void selectInstruction (String instruction) {
		Select dropdown = new Select(champInstruction);
		dropdown.selectByValue(instruction);
	}
	
	public void clickCroixInstructions () {
		croixInstruction.click();
	}



	//Méthode pour les boutons en bas de la page
	public PagePrincipaleDSE clickEnvoyerCourriel (WebDriver driver) {
		btnEnvoyerCourriel.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}

	public PagePrincipaleDSE clickAnnuler (WebDriver driver) {
		btnAnnuler.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public PagePrincipaleDSE clickNotifier (WebDriver driver) {
		btnNotifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public PagePrincipaleDSE clickPurger (WebDriver driver) {
		btnPurger.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	
	
	//Méthode pour envoyer du texte dans le corps
	public void sendText (String text) {
		champTexte.sendKeys(text);
	}
}
