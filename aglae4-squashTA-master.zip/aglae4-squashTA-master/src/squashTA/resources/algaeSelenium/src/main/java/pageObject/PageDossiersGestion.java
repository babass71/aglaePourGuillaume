package pageObject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class PageDossiersGestion extends MenuHorrizontal{
	
	public PageDossiersGestion(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	@FindBy (xpath="//input[@id='siAu']") WebElement champAnnee;
	@FindBy (xpath="//input[@id='iNe']") WebElement champINE;
	@FindBy (xpath="//form/table/tbody/tr[7]/td/input[1]") WebElement boutonCreer;
	@FindBy (xpath="//input[@value='Ouvrir']") WebElement boutonOuvrir;
	//@FindBy (xpath="//input[@value='Annuler']") WebElement boutonEffacer;
	//Boutons du menu horizontal
	@FindBy (xpath="//td[@id='tdStructures']") WebElement BtnMenuStructures;
	@FindBy (xpath="//td[@id='tdDossiers']") WebElement BtnMenuDossiers;
	@FindBy (xpath="//td[@id='tdOutils']") WebElement BtnMenuOutils;
	
	public void AssertAllElementsOfPageDossiersGestion (String academie, String codeHabilitation) {
		//Vérifier la présence des boutons du menu horizontal
	    driver.findElements(By.xpath("//td[@id='tdStructures']"));
	    driver.findElements(By.xpath("//td[@id='tdDossiers']"));
		driver.findElements(By.xpath("//td[@id='tdOutils']"));
		//Vérifier titre page
		String titre = driver.findElement(By.xpath("//div[@class='nompage']")).getText();
		assertEquals(titre, "dseListe.jsp");
		//Vérifier Académie et Login
		driver.findElement(By.xpath("//td/font[contains(text(), '"+ academie +" ')]"));
		driver.findElement(By.xpath("//td/font[contains(text(), '"+ academie + codeHabilitation +"')]"));
		//Lien vers aide et quitter
		driver.findElement(By.xpath("//a/img[@src='/aglae3/images/aide.gif']"));
		driver.findElement(By.xpath("//a/img[@src='/aglae3/images/sortir.gif']"));
		//Sous boutons du menu Dossiers
		driver.findElement(By.xpath("//td/a[contains(text(), 'Gestion')]"));
		driver.findElement(By.xpath("//td/a[contains(text(), 'Extraction')]"));
		driver.findElement(By.xpath("//td/a[contains(text(), 'Edition')]"));
		driver.findElement(By.xpath("//td/a[contains(text(), 'Changer')]"));
		driver.findElement(By.xpath("//td/a[contains(text(), 'Jeton')]"));
		//Boutons interactifs Créer, ouvrir et rechercher
		driver.findElement(By.xpath("//tr/td/input[@tabindex='4']"));
		driver.findElement(By.xpath("//tr/td/input[@tabindex='3']"));
		driver.findElement(By.xpath("//tr/td/input[@value='Rechercher']"));
	}


	public PagePrincipaleDSE creerEtudiant (WebDriver driver, String annee, String INE) throws InterruptedException {
		champAnnee.clear();
		champAnnee.sendKeys(annee);
		champINE.sendKeys(INE);
		boutonCreer.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public PagePrincipaleDSE ouvrirEtudiant (WebDriver driver, String annee, String INE) throws InterruptedException {
		champAnnee.clear();
		champAnnee.sendKeys(annee);
		champINE.sendKeys(INE);
		boutonOuvrir.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
		
	public void creerEtudiantEchec (WebDriver driver, String INE) throws InterruptedException {
		champAnnee.clear();
		champINE.sendKeys(INE);
		boutonCreer.click(); 
	}
	
	public PagePrincipaleDSE creerEtudiantNotAllowed (WebDriver driver, String annee, String INE) throws InterruptedException {
		champAnnee.clear();
		champAnnee.sendKeys(annee);
		champINE.sendKeys(INE);
		boutonCreer.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public Map<String,String> recupDignostic(WebDriver driver){
		
		
		List<WebElement> enteteDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[2]"));
		List<WebElement> contenuDiag = driver.findElements(By.xpath("//td[@class='erreur']/../td[3]"));
		
		List<String> listeEnteteDiag =enteteDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		List<String> listeContenuDiag =contenuDiag.stream().map(WebElement::getText).collect(Collectors.toList());
		Map <String,String> map = new HashMap<String,String>();
			for (int i = 0; i < listeEnteteDiag.size(); i++) {
				map.put(listeEnteteDiag.get(i), listeContenuDiag.get(i));
			}
		return map;
		
	}
	
}
