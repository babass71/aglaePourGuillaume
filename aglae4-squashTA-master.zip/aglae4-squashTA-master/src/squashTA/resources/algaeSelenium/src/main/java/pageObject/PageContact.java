package pageObject;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageContact {
	
	private WebDriver driver;

	public PageContact(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
@FindBy (xpath="//tr[4]//tr[2]/td[1]/input[1]") WebElement btnModifier;
@FindBy (xpath="//tr[4]//tr[2]/td[1]/input[2]") WebElement btnQuitter;
	

//Méthode pour les boutons en bas de la page
	public PagePrincipaleDSE clickModifier (WebDriver driver) {
		btnModifier.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	public PagePrincipaleDSE clickQuitter (WebDriver driver) {
		btnQuitter.click();
		return PageFactory.initElements(driver, PagePrincipaleDSE.class);
	}
	
	
//Méthode pour generer un numero de telephone aleatoire
	public String GenererTelephoneAleatoire () {
		int length = 8;
		boolean useLetters = false;
		boolean useNumbers = true;
		String generatedString = RandomStringUtils.random(length, useLetters, useNumbers);
		generatedString = generatedString.toLowerCase();
		String generatedtelephone = "06" + generatedString;
		return generatedtelephone;
	}
	
//Méthode pour remplir les champs contact (integer pour choisir contact 1 2 ou 3)
	public void remplissageContact(int rangContact, String numeroTelString, String numVoieString, String compAdresse1String, String compAdresse2String, String localiteString, String paysString, String codePostalString) {
		renseignerTelephoneContact(rangContact, numeroTelString);
		renseignerNumeroEtVoie(rangContact, numVoieString);
		renseignerComplementAdresse1(rangContact, compAdresse1String);
		renseignerComplementAdresse2(rangContact, compAdresse2String);
		renseignerLocalite(rangContact, localiteString);
		renseignerPays(rangContact, paysString);
		renseignerCodePostal(rangContact, codePostalString);
	}
	
//Méthode pour remplir les champs contact
	public void renseignerTelephoneContact (int rangContact, String numeroTelString) {
		WebElement Telephone = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/input"));
		Telephone.sendKeys(numeroTelString);
	}
	
	public void renseignerNumeroEtVoie (int rangContact, String numVoieString) {
		WebElement numeroEtVoie = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[2]/td[2]/input"));
		numeroEtVoie.sendKeys(numVoieString);
	}
	
	public void renseignerComplementAdresse1 (int rangContact, String compAdresse1String) {
		WebElement complementAdresse1 = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[3]/td[2]/input"));
		complementAdresse1.sendKeys(compAdresse1String);
	}
	
	public void renseignerComplementAdresse2 (int rangContact, String compAdresse2String) {
		WebElement complementAdresse2 = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[4]/td[2]/input"));
		complementAdresse2.sendKeys(compAdresse2String);
	}
	
	public void renseignerLocalite (int rangContact, String localiteString) {
		WebElement localite = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[5]/td[2]/input"));
		localite.sendKeys(localiteString);
	}
	
	public void renseignerPays (int rangContact, String paysString) {
		WebElement paysDropdown = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[6]/td[2]/select"));
		Select dropdown = new Select(paysDropdown);
		dropdown.selectByValue(paysString);	
	}
	
	public void renseignerCodePostal (int rangContact, String codePostalString) {
		WebElement codePostal = driver.findElement(By.xpath("//table["+rangContact+"]/tbody/tr[3]/td/table/tbody/tr[7]/td[2]/input"));
		codePostal.sendKeys(codePostalString);
	}
	
}

