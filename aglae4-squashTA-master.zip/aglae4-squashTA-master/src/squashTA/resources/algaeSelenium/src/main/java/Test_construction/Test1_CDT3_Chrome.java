package Test_construction;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;
import pageObject.PageDossier;
import pageObject.PageDossiersGestion;
import pageObject.PageEditions;
import pageObject.PageEtudiant;
import pageObject.PageHistorique;
import pageObject.PageInstructions;
import pageObject.PageLogin;
import pageObject.PagePaiementVoeu0;
import pageObject.PagePrincipaleDSE;
import pageObject.PageTexte;
import pageObject.PageVoeu0;
import pageObject.PageVoeux;
import test.ChromeDriverSetup;
import test.FirefoxDriverSetup;
import pageObject.PageHistorique;
import pageObject.CreerPageHistorique;
import utils.OutilsProjet;

public class Test1_CDT3_Chrome extends ChromeDriverSetup{
	
	@Test
	public void run() throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 20);
		PageLogin pageLogin = PageFactory.initElements(driver, PageLogin.class);
		Properties properties = new Properties();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream("fileCasNomial.properties");
		
		LOGGER.info("---------------> Cas de test 1 : Creation d'un �tudiant avec les donnees minimales <---------------" );
		properties.load(file);
		String login=properties.getProperty("loginModo");
		String mdp=properties.getProperty("mdp007");
		String anneeEtudiant=properties.getProperty("annee2019");
		String INE=properties.getProperty("INERandom");
		
		String acaAssert = login.substring(0,3);
		String autoAssert = login.substring(3);
		System.out.println(acaAssert);
		System.out.println(autoAssert);
		LOGGER.info(acaAssert);
		LOGGER.info(autoAssert);
		
		LOGGER.info("Pas de test 1 : ouverture de la session avec les login "+login +" et mot de passe" + mdp );
		PageDossiersGestion pageDossiersGestion = pageLogin.seConnecter(login, mdp);
		LOGGER.info("Verification de la bonne organisation de la page d'accueil d'Aglae");
		Thread.sleep(2000);
		pageDossiersGestion.AssertAllElementsOfPageDossiersGestion(acaAssert, autoAssert);
		
		LOGGER.info("Pas de test 2 : synchronisation de la page et ajout de l'"+anneeEtudiant+" dans le champ annee et "+INE+" dans le champ INE");
		PagePrincipaleDSE pagePrincipaleDSE = pageDossiersGestion.creerEtudiant(driver, anneeEtudiant, INE);
		pagePrincipaleDSE.AssertAllElementsOfPagePrincipaleDSE();
		
		LOGGER.info("Pas de test 3 : Renseignement des informations de la section Etudiant" );
		PageEtudiant pageEtudiant= pagePrincipaleDSE.clicketudiant();
		Thread.sleep(2000);
		String INERecup = pageEtudiant.recupINE(driver);
		LOGGER.info("Recuperation de l'INE genere : " +INERecup );
		pageEtudiant.recupDate();
		LOGGER.info("Verification que la date de creation est egale a la date de modification" );
		String genre=properties.getProperty("genreMasculin");
		String nom=pageEtudiant.GenererNomAleatoire();
		String prenom=pageEtudiant.GenererNomAleatoire();
		String courriel=pageEtudiant.GenererMailAleatoire();
		String dateNaissance=properties.getProperty("dateNaissance");
		String situationFamiliale=properties.getProperty("celibataire");
		String recupINE = pageEtudiant.recupINE(driver);
		String nationalite=properties.getProperty("france");
		String situationEtranger=properties.getProperty("franceAndorre");
		LOGGER.debug("�l�ve g�ner� avec l'INE " + recupINE);
		LOGGER.debug("�l�ve g�n�r� avec le pr�nom " + prenom);
		LOGGER.debug("�l�ve g�n�r� avec le nom " + nom);
		
		PagePrincipaleDSE PagePrincipaleDSE = pageEtudiant.remplissageMinimal(driver, genre, nom, prenom, dateNaissance, situationFamiliale, courriel, nationalite, situationEtranger);
		//V�rifier la liste des erreurs sur la page principale apr�s remplissage d'Etudiant
		Map<String,String> actualTableauMessage = pagePrincipaleDSE.recupMapDiagnostic(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier = OutilsProjet.orderAscendingMap(actualTableauMessage);
		
		
		
		System.out.println(actualTableauMessageTrier);
		Map<String,String> mapReferenceMessageDossier=OutilsProjet.getMapFromFile("Diagnostics/diagnosticDossier.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier);
		System.out.println(mapReferenceMessageDossierTrier);	
		assertEquals(mapReferenceMessageDossierTrier, actualTableauMessageTrier);
		
		LOGGER.info("Pas de test 4 : Renseignement des informations de la section Dossier" );
		PageDossier pageDossier = pagePrincipaleDSE.clickdossier();
		Thread.sleep(1000);
		String rue=properties.getProperty("rue");
		String cp=properties.getProperty("cp");
		String ville=properties.getProperty("ville");
		String pays=properties.getProperty("pays");
		String AC=properties.getProperty("Valide");
		pageDossier.renseignerAdresse(rue, cp, ville, pays, AC);
		pageDossier.clickModifier(driver);
		//V�rifier la liste des erreurs sur la page principale apr�s remplissage du Dossier
		Map<String,String> actualTableauMessage2 = pagePrincipaleDSE.recupMapDiagnostic(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier2 = OutilsProjet.orderAscendingMap(actualTableauMessage2);
		System.out.println(actualTableauMessageTrier2);
		Map<String,String> mapReferenceMessageDossier2=OutilsProjet.getMapFromFile("Diagnostics/diagnosticDossierComplet.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier2 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier2);
		System.out.println(mapReferenceMessageDossierTrier2);	
		assertEquals(mapReferenceMessageDossierTrier2, actualTableauMessageTrier2);
		
		LOGGER.info("Pas de test 5 : Renseignement un voeu basique accompagn� d'une demande d'aide" );
		//remplir Etudes dans voeux
		PageVoeux pageVoeux = pagePrincipaleDSE.clickVoeuxPlus(1);
		Thread.sleep(1000);
		String toto3 = pageDossier.recupNombreBloc(driver);
		LOGGER.info("comptage du nombre de bloc dans la page Voeux" );
		Assert.assertTrue("Le nombre de bloc doit �tre �gal � 3", toto3.equals("3"));
		String ACVoeu =properties.getProperty("AcademiePARIS");
		String secteurVoeu =properties.getProperty("secteur1");
		String paysVoeu =properties.getProperty("paysFRANCE");
		String EtaVoeu =properties.getProperty("etablissementA");
		String typeCursusVoeu =properties.getProperty("cursusLMD");
		String formationVoeu =properties.getProperty("cursusLicence");
		String progLMDVoeu =properties.getProperty("Licence");
		String Branche =properties.getProperty("Sans_objet");
		String Semestre =properties.getProperty("InscriptionSemestrielle");
		//remplir Aides dans voeux
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu, secteurVoeu, paysVoeu, typeCursusVoeu, formationVoeu, progLMDVoeu, EtaVoeu, Branche, Semestre);
		String categorieVoeu1 =properties.getProperty("Principale");
		String codeVoeu1 =properties.getProperty("BourseSurCriteresSociaux");
		pageVoeux.ajouterVoeuAides(driver);
		pageVoeux.remplissageVoeuAidesStandard(driver, 1, categorieVoeu1, codeVoeu1);
		//pageVoeux.remplissageVoeuAidesRestreint(driver, categorieVoeu1, codeVoeu1);
		pageVoeux.clickAjouter(driver);
		
		LOGGER.info("Pas de test 6 : Enregistment du DSE avec envoi de NU" );
		PagePrincipaleDSE.CaseCocherNU();
		PagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage3 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier3 = OutilsProjet.orderAscendingMap(actualTableauMessage3);
		System.out.println(actualTableauMessageTrier3);
		Map<String,String> mapReferenceMessageDossier3=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEnregistrerDossierComplet.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier3 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier3);
		System.out.println(mapReferenceMessageDossierTrier3);	
		assertEquals(mapReferenceMessageDossierTrier3, actualTableauMessageTrier3);
		Thread.sleep(1000);
		PagePrincipaleDSE.QuitterDossierValide();
		
		
		
		
		LOGGER.info("---------------> Cas de test 2 : Ajouter une demande de logement sur le m�me voeu et contr�ler les donn�es en base <---------------" );
		String INE2=INERecup;
		LOGGER.info("Pas de test 1 : ouvrir le voeu d�ja cr�� depuis la page de consultation du DSE");
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.clickVoeuxEditer(1);
		
		LOGGER.info("Pas de test 2 : Enregistrement du DSE");
		String ACl =properties.getProperty("AcademieLogPARIS");
		String secteurl =properties.getProperty("secteurLog1");
		String paysl =properties.getProperty("paysLogFRANCE");
		String ResD =properties.getProperty("residence");
		String TypLogD =properties.getProperty("logementT1");
		String NbCohabD =properties.getProperty("1cohabitant");
		String CatD =properties.getProperty("logementConventionne");	
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACl, secteurl, paysl, ResD, TypLogD, NbCohabD, CatD);
		pageVoeux.clickModifier(driver);
		
		LOGGER.info("Pas de test 3 : Enregistrement des modifications et sortie du dossier");
		PagePrincipaleDSE.CaseCocherNU();
		PagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage4 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier4 = OutilsProjet.orderAscendingMap(actualTableauMessage4);
		System.out.println(actualTableauMessageTrier4);
		Map<String,String> mapReferenceMessageDossier4=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier4 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier4);
		System.out.println(mapReferenceMessageDossierTrier4);	
		assertEquals(mapReferenceMessageDossierTrier4, actualTableauMessageTrier4);
		Thread.sleep(1000);
		PagePrincipaleDSE.QuitterDossierValide();
		
		
		
		
		LOGGER.info("---------------> Cas de test 3 : Ajouter un voeu avec demande de logement <---------------" );
		LOGGER.info("Pas de test 1 : Cr�er un nouveau voeu depuis la page de consultation du DSE");
		pageDossiersGestion.ouvrirEtudiant(driver, anneeEtudiant, INE2);
		Thread.sleep(1000);
		pagePrincipaleDSE.clickVoeuxPlus(2);
		
		LOGGER.info("Pas de test 2 : Ajout du voeu");
		String ACVoeu2 =properties.getProperty("AcademiePARIS");
		String secteurVoeu2 =properties.getProperty("secteur1");
		String paysVoeu2 =properties.getProperty("paysFRANCE");
		String EtaVoeu2 =properties.getProperty("etablissementB");
		String typeCursusVoeu2 =properties.getProperty("cursusLMD");
		String formationVoeu2 =properties.getProperty("cursusLicence");
		String progLMDVoeu2 =properties.getProperty("Licence");
		String Branche2 =properties.getProperty("Sans_objet");
		String Semestre2 =properties.getProperty("InscriptionSemestrielle");
		pageVoeux.remplissageVoeuEtude(driver, ACVoeu2, secteurVoeu2, paysVoeu2, typeCursusVoeu2, formationVoeu2, progLMDVoeu2, EtaVoeu2, Branche2, Semestre2);
		
		LOGGER.info("Pas de test 3 : Ajout de la demande de logement et validation du voeu");
		String ACl2 =properties.getProperty("AcademieLogPARIS");
		String secteurl2 =properties.getProperty("secteurLog1");
		String paysl2 =properties.getProperty("paysLogFRANCE");
		String ResD2 =properties.getProperty("residence");
		String TypLogD2 =properties.getProperty("logementT1");
		String NbCohabD2 =properties.getProperty("1cohabitant");
		String CatD2 =properties.getProperty("logementConventionne");	
		pageVoeux.remplissageVoeuLogementMinimal(driver, ACl2, secteurl2, paysl2, ResD2, TypLogD2, NbCohabD2, CatD2);
		pageVoeux.clickAjouter(driver);
		
		LOGGER.info("Pas de test 4 : Enregistrement du DSE");
		PagePrincipaleDSE.CaseCocherNU();
		PagePrincipaleDSE.clickEnregistrer();
		Map<String,String> actualTableauMessage5 = pagePrincipaleDSE.recupMapPositif(driver);
		LinkedHashMap<String,String> actualTableauMessageTrier5 = OutilsProjet.orderAscendingMap(actualTableauMessage5);
		System.out.println(actualTableauMessageTrier5);
		Map<String,String> mapReferenceMessageDossier5=OutilsProjet.getMapFromFile("Diagnostics/diagnosticEditionVoeu.txt");
		LinkedHashMap<String,String> mapReferenceMessageDossierTrier5 = OutilsProjet.orderAscendingMap(mapReferenceMessageDossier5);
		System.out.println(mapReferenceMessageDossierTrier5);	
		Assert.assertEquals(mapReferenceMessageDossierTrier5, actualTableauMessageTrier5);
		Thread.sleep(1000);
		PagePrincipaleDSE.QuitterDossierValide();
	}

	/***
	 * 
	 * @param pagePrincipaleDSE (ne pas changer, pr�chargement de la pageobject indispensable)
	 * @param rangVoeu (num�ro du voeu � renseigner, donc rang 1, 2 ou 3 etc...)
	 * @param colonneVoeu (num�ro de la colonne � renseigner, /!\Les colonnes vides doivent �tre compt�es : 2 Pour Etude, 3 Pour Logement, 5 Pour Aide(s), 7 pour Actions))
	 * @param ligneVoeu (num�ro la ligne du voeu (ex, pour �tude, c'est 1 pour acad�mie, 2 pour cursus et 3 pour l'�tablissement) : Rien � faire � part renseigner l'int ligneVoeu)
	 * @param numeroFichierProperties (num�ro du fichier de properties � charger contenant les strings attendues)
	 * @throws IOException
	 */
	public void VerifierRemplissageVoeux (PagePrincipaleDSE pagePrincipaleDSE, int rangVoeu, int colonneVoeu, int ligneVoeu, int numeroFichierProperties) throws IOException {
		Properties voeuxProperties = new Properties();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream("fileVoeuxProperties"+numeroFichierProperties+".properties");
		voeuxProperties.load(file);
		String VoeuRangColonneLigneExpected =voeuxProperties.getProperty("VoeuRang"+rangVoeu+"Colonne"+colonneVoeu+"Ligne"+ligneVoeu+"Expected");
		String VoeuRangColonneLigneActual =pagePrincipaleDSE.recupVoeu(+rangVoeu, +colonneVoeu, +ligneVoeu);
		System.out.println(VoeuRangColonneLigneActual);
		System.out.println(VoeuRangColonneLigneExpected);
		assertEquals(VoeuRangColonneLigneExpected, VoeuRangColonneLigneActual);
	}
}
