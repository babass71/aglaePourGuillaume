package pageObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class AbstractPage {
	//public final WebDriver driver;
	
	public AbstractPage(WebDriver driver) {
		super();
		// TODO Auto-generated constructor stub
	}
	

//	@FindBy(xpath="//a[.='Utilisateurs']")WebElement boutonUtilisateurs;
	

//	@FindBy(id="window_confirm_answer_no") WebElement boutonNoPopUpViderPanier;
	

}
