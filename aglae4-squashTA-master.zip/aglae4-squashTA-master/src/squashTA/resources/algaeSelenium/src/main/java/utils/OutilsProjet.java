package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.NewSessionPayload;

import utils.MapFilter;

public class OutilsProjet {
	
	public static void _checkTheChekcbox(WebElement webElement) {
		if (!webElement.isSelected())
		{
			webElement.click();
		}
		
	}
	public static void _uncheckTheChekcbox(WebElement webElement) {
		if (webElement.isSelected())
		{
			webElement.click();
		}
		
	}
	/**
	 * Reads a "properties" file, and returns it as a Map 
	 * (a collection of key/value pairs).
	 * 
	 * @param filename  The properties filename to read.
	 * @param delimiter The string (or character) that separates the key 
	 *                  from the value in the properties file.
	 * @return The Map that contains the key/value pairs.
	 * @throws IOException 
	 * @throws Exception
	 */
/*	public static Map<String, String> readPropertiesFileAsMap(String filename, String delimiter)
			throws Exception
			{
			  Map<String, String> map = new HashMap();
			  BufferedReader reader = new BufferedReader(new FileReader(filename));
			  String line;
			  while ((line = reader.readLine()) != null)
			  {
			    if (line.trim().length()==0) continue;
			    if (line.charAt(0)=='#') continue;
			    // assumption here is that proper lines are like "String : http://xxx.yyy.zzz/foo/bar",
			    // and the ":" is the delimiter
			    int delimPosition = line.indexOf(delimiter);
			    String key = line.substring(0, delimPosition-1).trim();
			    String value = line.substring(delimPosition+1).trim();
			    map.put(key, value);
			  }
			  reader.close();
			  return map;
			}
*/
	
	public static Set<String> filterPropertyFile(String path, String arg) throws IOException{
		
		
        try (InputStream configInput = Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {

            Properties conf = new Properties();
            conf.load(configInput);

            /**
             *  Simple transcription en Mpa de String String pour que ce soit plus simple à traiter
             *  Car initialement pour des raison de retro compat avec Java 1 et l'introdution des générique
             *  Cans Java 1.5 une Properties est une Map<Object,Object>. Donc on cast violemment car on sait que l'on
             *  que des String !
             */

            @SuppressWarnings({"uncheked","rawtypes"})
            Map<String,String> confMap = new HashMap(conf);


            /** Display of Map content for debuging purposes **/
            System.out.println("Display of Map content for debuging purposes");
            for (String key : confMap.keySet() ) {
                System.out.println("Clef : " + key + " -- Valeur " + confMap.get(key));
            }

            final MapFilter<String, String> mapFilter = new MapFilter<>(confMap);

            final Set<String> keysPointingToArg = mapFilter.filter(arg);

            /** Display ofKeys pointing to "oui" for debugging purposes**/
            System.out.println("Display ofKeys pointing to \"oui\" for debugging purposes");
            for (String key : keysPointingToArg) {
                System.out.println("Clef : " + key );
            }
            return keysPointingToArg;
        }
        
		
	}
	
	public static void switchNewWindows(WebDriver driver, String parentWinHandle) throws InterruptedException {
        Set<String> winHandles = driver.getWindowHandles();
        // Loop through all handles
        for(String handle: winHandles){
            if(!handle.equals(parentWinHandle)){
            driver.switchTo().window(handle);
            Thread.sleep(2000);
            System.out.println("Title of the new window: " +
driver.getTitle());
//            System.out.println("Closing the new window...");
 //           driver.close();
            }
        }

	}
	
	public static void switchToParentWindows(WebDriver driver, String parentWinHandle) {
		driver.close();
		driver.switchTo().window(parentWinHandle);
		
	}
	/**
	 * methode permettant de 
	 * @param filePath
	 * @return resultMap
	 * @throws IOException
	 */
	public static Map<String, String> getMapFromCSV(final String filePath) throws IOException{
        Stream<String> lines = Files.lines(Paths.get(filePath));
        Map<String, String> resultMap = 
                lines.map(line -> line.split(","))
                     .collect(Collectors.toMap(line -> line[0], line -> line[1]));

        lines.close();

        return resultMap;
    }
	public static LinkedHashMap<String,String> orderAscendingMap(Map <String,String> unSortedMap){
		
		LinkedHashMap<String, String> sortedMap = new LinkedHashMap<>();
		 
		unSortedMap.entrySet()
		    .stream()
		    .sorted(Map.Entry.comparingByKey())
		    .forEachOrdered(x -> sortedMap.put(x.getKey(), x.getValue()));
		return sortedMap;
	}
	public static Map<String, String> getMapFromFile(final String filePath) throws IOException{
			URL toto = OutilsProjet.class.getClassLoader().getResource(filePath);
			File totoResource = new File(toto.getFile());
	        Stream<String> lines = Files.lines(totoResource.toPath());
	        Map<String, String> resultMap = 
	                lines.map(line -> line.split(","))
	                     .collect(Collectors.toMap(line -> line[0], line -> line[1]));

	        lines.close();

	        return resultMap;
	    }

}
